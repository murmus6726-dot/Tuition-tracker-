package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.HabitDetailDialog
import com.example.ui.components.PostClassReviewDialog
import com.example.ui.screens.*
import com.example.ui.theme.TuitionTrackerTheme
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.TuitionViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TuitionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIntentExtras(intent)

        setContent {
            TuitionTrackerTheme {
                MainTuitionApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntentExtras(intent)
    }

    private fun handleIntentExtras(intent: Intent?) {
        val dest = intent?.getStringExtra("navigate_to")
        when (dest) {
            "focus" -> viewModel.navigateTo(AppDestination.FOCUS)
            "homework" -> viewModel.navigateTo(AppDestination.HOMEWORK)
            "schedule" -> viewModel.navigateTo(AppDestination.SCHEDULE)
            "notes" -> viewModel.navigateTo(AppDestination.NOTES)
            "review" -> {
                val classId = intent.getLongExtra("class_id", -1L)
                if (classId != -1L) {
                    val target = viewModel.allClasses.value.find { it.id == classId }
                    if (target != null) {
                        viewModel.openPostClassReview(target)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTuitionApp(viewModel: TuitionViewModel) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val reviewClass by viewModel.showReviewDialog.collectAsState()
    val habitDetailName by viewModel.selectedHabitDetail.collectAsState()
    val habitRecord by viewModel.selectedDateHabit.collectAsState()
    val pendingHw by viewModel.pendingHomework.collectAsState()
    val focusState by viewModel.focusState.collectAsState()

    // Dialogs
    if (reviewClass != null) {
        PostClassReviewDialog(
            tuitionClass = reviewClass!!,
            onDismiss = { viewModel.dismissReviewDialog() },
            onSubmit = { attended, pages, rating, hwDone ->
                viewModel.submitPostClassReview(reviewClass!!, attended, pages, rating, hwDone)
            }
        )
    }

    if (habitDetailName != null) {
        HabitDetailDialog(
            habitName = habitDetailName!!,
            habitRecord = habitRecord,
            onDismiss = { viewModel.closeHabitDetail() },
            onUpdateExercise = { done, notes -> viewModel.updateExerciseHabit(done, notes) },
            onUpdateMeditation = { done, mins -> viewModel.updateMeditationHabit(done, mins) }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentDestination) {
                            AppDestination.HOME -> "Tuition Tracker"
                            AppDestination.SCHEDULE -> "Timetable"
                            AppDestination.FOCUS -> "Focus Mode"
                            AppDestination.HOMEWORK -> "Homework"
                            AppDestination.NOTES -> "Class Notes"
                            AppDestination.CALENDAR -> "Calendar"
                            AppDestination.ANALYTICS -> "Analytics"
                            AppDestination.SETTINGS -> "Settings"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppDestination.CALENDAR) },
                        modifier = Modifier.testTag("top_bar_calendar")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Calendar",
                            tint = if (currentDestination == AppDestination.CALENDAR) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = { viewModel.navigateTo(AppDestination.ANALYTICS) },
                        modifier = Modifier.testTag("top_bar_analytics")
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = "Analytics",
                            tint = if (currentDestination == AppDestination.ANALYTICS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = { viewModel.navigateTo(AppDestination.SETTINGS) },
                        modifier = Modifier.testTag("top_bar_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = if (currentDestination == AppDestination.SETTINGS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = currentDestination == AppDestination.HOME,
                    onClick = { viewModel.navigateTo(AppDestination.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_home")
                )

                NavigationBarItem(
                    selected = currentDestination == AppDestination.SCHEDULE,
                    onClick = { viewModel.navigateTo(AppDestination.SCHEDULE) },
                    icon = { Icon(Icons.Default.Schedule, contentDescription = "Schedule") },
                    label = { Text("Schedule") },
                    modifier = Modifier.testTag("nav_schedule")
                )

                NavigationBarItem(
                    selected = currentDestination == AppDestination.FOCUS,
                    onClick = { viewModel.navigateTo(AppDestination.FOCUS) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (focusState.isActive) {
                                    Badge { Text("ON") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.FilterCenterFocus, contentDescription = "Focus")
                        }
                    },
                    label = { Text("Focus") },
                    modifier = Modifier.testTag("nav_focus")
                )

                NavigationBarItem(
                    selected = currentDestination == AppDestination.HOMEWORK,
                    onClick = { viewModel.navigateTo(AppDestination.HOMEWORK) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (pendingHw.isNotEmpty()) {
                                    Badge { Text("${pendingHw.size}") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Assignment, contentDescription = "Homework")
                        }
                    },
                    label = { Text("Homework") },
                    modifier = Modifier.testTag("nav_homework")
                )

                NavigationBarItem(
                    selected = currentDestination == AppDestination.NOTES,
                    onClick = { viewModel.navigateTo(AppDestination.NOTES) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = "Notes") },
                    label = { Text("Notes") },
                    modifier = Modifier.testTag("nav_notes")
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentDestination,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "ScreenTransition",
            modifier = Modifier.padding(innerPadding)
        ) { destination ->
            when (destination) {
                AppDestination.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateTo = { viewModel.navigateTo(it) }
                )
                AppDestination.SCHEDULE -> ScheduleScreen(viewModel = viewModel)
                AppDestination.FOCUS -> FocusScreen(viewModel = viewModel)
                AppDestination.HOMEWORK -> HomeworkScreen(viewModel = viewModel)
                AppDestination.NOTES -> NotesScreen(viewModel = viewModel)
                AppDestination.CALENDAR -> CalendarScreen(viewModel = viewModel)
                AppDestination.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                AppDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
