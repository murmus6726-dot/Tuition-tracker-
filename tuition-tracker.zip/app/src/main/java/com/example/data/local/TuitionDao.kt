package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TuitionDao {

    // Subjects
    @Query("SELECT * FROM subjects ORDER BY name ASC")
    fun getAllSubjects(): Flow<List<Subject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: Subject): Long

    @Delete
    suspend fun deleteSubject(subject: Subject)

    // Tuition Classes
    @Query("SELECT * FROM tuition_classes ORDER BY dateMillis ASC, startTimeMinute ASC")
    fun getAllClasses(): Flow<List<TuitionClass>>

    @Query("SELECT * FROM tuition_classes WHERE dateMillis = :dateMillis ORDER BY startTimeMinute ASC")
    fun getClassesForDate(dateMillis: Long): Flow<List<TuitionClass>>

    @Query("SELECT * FROM tuition_classes WHERE dateMillis = :dateMillis ORDER BY startTimeMinute ASC")
    suspend fun getClassesForDateSync(dateMillis: Long): List<TuitionClass>

    @Query("SELECT * FROM tuition_classes WHERE id = :id")
    suspend fun getClassById(id: Long): TuitionClass?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(tuitionClass: TuitionClass): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<TuitionClass>)

    @Update
    suspend fun updateClass(tuitionClass: TuitionClass)

    @Delete
    suspend fun deleteClass(tuitionClass: TuitionClass)

    // Study Sessions
    @Query("SELECT * FROM study_sessions ORDER BY startTimeMillis DESC")
    fun getAllStudySessions(): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE sessionDateMillis = :dateMillis ORDER BY startTimeMillis DESC")
    fun getStudySessionsForDate(dateMillis: Long): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE sessionDateMillis = :dateMillis")
    suspend fun getStudySessionsForDateSync(dateMillis: Long): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE sessionDateMillis >= :startMillis AND sessionDateMillis <= :endMillis")
    suspend fun getStudySessionsInRange(startMillis: Long, endMillis: Long): List<StudySession>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySession): Long

    @Update
    suspend fun updateStudySession(session: StudySession)

    // Emergency Breaks
    @Query("SELECT * FROM emergency_breaks WHERE sessionId = :sessionId ORDER BY breakNumber ASC")
    fun getBreaksForSession(sessionId: Long): Flow<List<EmergencyBreakRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyBreak(breakRecord: EmergencyBreakRecord): Long

    @Update
    suspend fun updateEmergencyBreak(breakRecord: EmergencyBreakRecord)

    // Homework
    @Query("SELECT * FROM homework ORDER BY isCompleted ASC, deadlineMillis ASC")
    fun getAllHomework(): Flow<List<Homework>>

    @Query("SELECT * FROM homework WHERE isCompleted = 0 ORDER BY deadlineMillis ASC")
    fun getPendingHomework(): Flow<List<Homework>>

    @Query("SELECT * FROM homework WHERE id = :id")
    suspend fun getHomeworkById(id: Long): Homework?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework): Long

    @Update
    suspend fun updateHomework(homework: Homework)

    @Delete
    suspend fun deleteHomework(homework: Homework)

    // Class Notes
    @Query("SELECT * FROM class_notes ORDER BY dateMillis DESC, createdAt DESC")
    fun getAllNotes(): Flow<List<ClassNote>>

    @Query("SELECT * FROM class_notes WHERE classId = :classId")
    fun getNotesForClass(classId: Long): Flow<List<ClassNote>>

    @Query("SELECT * FROM class_notes WHERE subjectName = :subjectName ORDER BY dateMillis DESC")
    fun getNotesForSubject(subjectName: String): Flow<List<ClassNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: ClassNote): Long

    @Update
    suspend fun updateNote(note: ClassNote)

    @Delete
    suspend fun deleteNote(note: ClassNote)

    // Habits
    @Query("SELECT * FROM habits WHERE dateMillis = :dateMillis")
    fun getHabitForDate(dateMillis: Long): Flow<HabitRecord?>

    @Query("SELECT * FROM habits WHERE dateMillis = :dateMillis")
    suspend fun getHabitForDateSync(dateMillis: Long): HabitRecord?

    @Query("SELECT * FROM habits WHERE dateMillis >= :startMillis AND dateMillis <= :endMillis ORDER BY dateMillis ASC")
    suspend fun getHabitsInRange(startMillis: Long, endMillis: Long): List<HabitRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitRecord)

    // Daily Performance
    @Query("SELECT * FROM daily_performance WHERE dateMillis = :dateMillis")
    fun getPerformanceForDate(dateMillis: Long): Flow<DailyPerformance?>

    @Query("SELECT * FROM daily_performance WHERE dateMillis = :dateMillis")
    suspend fun getPerformanceForDateSync(dateMillis: Long): DailyPerformance?

    @Query("SELECT * FROM daily_performance ORDER BY dateMillis DESC LIMIT 30")
    fun getRecentPerformance(): Flow<List<DailyPerformance>>

    @Query("SELECT * FROM daily_performance WHERE dateMillis >= :startMillis AND dateMillis <= :endMillis ORDER BY dateMillis ASC")
    suspend fun getPerformanceInRange(startMillis: Long, endMillis: Long): List<DailyPerformance>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerformance(performance: DailyPerformance)

    // Distraction Apps
    @Query("SELECT * FROM distraction_apps ORDER BY isAllowedStudyApp ASC, appName ASC")
    fun getAllDistractionApps(): Flow<List<DistractionApp>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistractionApp(app: DistractionApp)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistractionApps(apps: List<DistractionApp>)

    @Delete
    suspend fun deleteDistractionApp(app: DistractionApp)

    @Query("UPDATE distraction_apps SET isEnabled = :enabled WHERE packageName = :pkg")
    suspend fun updateDistractionAppStatus(pkg: String, enabled: Boolean)

    // User Settings
    @Query("SELECT * FROM user_settings WHERE id = 1")
    fun getUserSettings(): Flow<UserSettings?>

    @Query("SELECT * FROM user_settings WHERE id = 1")
    suspend fun getUserSettingsSync(): UserSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserSettings(settings: UserSettings)
}
