package com.example.data.repository

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.TuitionDatabase
import com.example.data.model.*
import com.example.receiver.TuitionAlarmReceiver
import com.example.service.UsageTrackerService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class TuitionRepository(
    private val database: TuitionDatabase,
    private val context: Context
) {
    private val dao = database.tuitionDao()

    // Observables
    val allSubjects: Flow<List<Subject>> = dao.getAllSubjects()
    val allClasses: Flow<List<TuitionClass>> = dao.getAllClasses()
    val allHomework: Flow<List<Homework>> = dao.getAllHomework()
    val pendingHomework: Flow<List<Homework>> = dao.getPendingHomework()
    val allNotes: Flow<List<ClassNote>> = dao.getAllNotes()
    val allStudySessions: Flow<List<StudySession>> = dao.getAllStudySessions()
    val allDistractionApps: Flow<List<DistractionApp>> = dao.getAllDistractionApps()
    val userSettings: Flow<UserSettings?> = dao.getUserSettings()
    val recentPerformance: Flow<List<DailyPerformance>> = dao.getRecentPerformance()

    suspend fun initializeDefaultsIfEmpty() {
        withContext(Dispatchers.IO) {
            val subjects = dao.getAllSubjects().firstOrNull()
            if (subjects.isNullOrEmpty()) {
                // Initialize default student subjects as shown in user prompt
                val faId = dao.insertSubject(Subject(name = "Financial Accounting", teacherName = "Prof. Roberts", colorHex = "#4338CA"))
                val meId = dao.insertSubject(Subject(name = "Microeconomics", teacherName = "Dr. Davis", colorHex = "#0284C7"))
                val pmId = dao.insertSubject(Subject(name = "Principles of Management", teacherName = "Prof. Sharma", colorHex = "#D97706"))
                val edId = dao.insertSubject(Subject(name = "Entrepreneurship Development", teacherName = "Dr. Clark", colorHex = "#10B981"))

                // Create initial weekly schedule template for the current week
                val calendar = Calendar.getInstance()
                val todayMidnight = getStartOfDay(calendar.timeInMillis)

                // Today's classes
                val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
                val morningStart = 8 * 60 // 8:00 AM
                val morningEnd = 9 * 60   // 9:00 AM

                // Financial Accounting today
                dao.insertClass(
                    TuitionClass(
                        subjectId = faId,
                        subjectName = "Financial Accounting",
                        teacherName = "Prof. Roberts",
                        dateMillis = todayMidnight,
                        startTimeMinute = morningStart,
                        endTimeMinute = morningEnd,
                        notes = "Balance sheet reconciliation and trial balance practice",
                        isRecurring = true,
                        recurringDays = "1,3,5", // Mon, Wed, Fri
                        status = if (currentHour < 8) "Upcoming" else if (currentHour == 8) "In Progress" else "Completed",
                        attended = currentHour >= 9,
                        attendanceRecorded = currentHour >= 9
                    )
                )

                // Microeconomics tomorrow
                val tomorrowMidnight = todayMidnight + 24 * 60 * 60 * 1000L
                dao.insertClass(
                    TuitionClass(
                        subjectId = meId,
                        subjectName = "Microeconomics",
                        teacherName = "Dr. Davis",
                        dateMillis = tomorrowMidnight,
                        startTimeMinute = morningStart,
                        endTimeMinute = morningEnd,
                        notes = "Elasticity of demand problem set",
                        isRecurring = true,
                        recurringDays = "2", // Tue
                        status = "Upcoming"
                    )
                )

                // Initial sample homework
                dao.insertHomework(
                    Homework(
                        title = "Chapter 4 Balance Sheet Analysis",
                        description = "Complete exercises 12 to 18 from textbook",
                        subjectName = "Financial Accounting",
                        deadlineMillis = tomorrowMidnight + 18 * 60 * 60 * 1000L, // Tomorrow 6:00 PM
                        notes = "Check formula on page 142",
                        manualPriority = "HIGH"
                    )
                )

                dao.insertHomework(
                    Homework(
                        title = "Elasticity Coefficient Case Study",
                        description = "Write a 2-page brief on supply elasticity in tech markets",
                        subjectName = "Microeconomics",
                        deadlineMillis = todayMidnight + 3 * 24 * 60 * 60 * 1000L,
                        notes = "Use ChatGPT for concept clarification",
                        manualPriority = "MEDIUM"
                    )
                )

                // Initial Distraction and Study apps list
                val defaultApps = listOf(
                    DistractionApp(packageName = "com.google.android.youtube", appName = "YouTube", isEnabled = true, isAllowedStudyApp = false),
                    DistractionApp(packageName = "com.instagram.android", appName = "Instagram", isEnabled = true, isAllowedStudyApp = false),
                    DistractionApp(packageName = "com.facebook.katana", appName = "Facebook", isEnabled = true, isAllowedStudyApp = false),
                    DistractionApp(packageName = "com.meesho.supply", appName = "Meesho", isEnabled = true, isAllowedStudyApp = false),
                    // Allowed Study Apps
                    DistractionApp(packageName = "com.openai.chatgpt", appName = "ChatGPT", isEnabled = true, isAllowedStudyApp = true),
                    DistractionApp(packageName = "com.google.android.calculator", appName = "Calculator", isEnabled = true, isAllowedStudyApp = true),
                    DistractionApp(packageName = "com.adobe.reader", appName = "PDF Reader", isEnabled = true, isAllowedStudyApp = true),
                    DistractionApp(packageName = "com.google.android.keep", appName = "Notes", isEnabled = true, isAllowedStudyApp = true)
                )
                dao.insertDistractionApps(defaultApps)

                // Initialize Settings
                dao.insertUserSettings(UserSettings())

                // Compute today's initial real performance
                recalculateDailyPerformance(todayMidnight)
            }
        }
    }

    fun getClassesForDate(dateMillis: Long): Flow<List<TuitionClass>> {
        return dao.getClassesForDate(getStartOfDay(dateMillis))
    }

    suspend fun getClassesForDateSync(dateMillis: Long): List<TuitionClass> {
        return withContext(Dispatchers.IO) {
            dao.getClassesForDateSync(getStartOfDay(dateMillis))
        }
    }

    /**
     * Checks if a tuition class would overlap with existing classes on the same date.
     */
    suspend fun checkClassOverlap(
        dateMillis: Long,
        startTimeMinute: Int,
        endTimeMinute: Int,
        excludeClassId: Long = 0
    ): Boolean {
        return withContext(Dispatchers.IO) {
            val existing = dao.getClassesForDateSync(getStartOfDay(dateMillis))
            existing.any {
                it.id != excludeClassId &&
                        startTimeMinute < it.endTimeMinute &&
                        endTimeMinute > it.startTimeMinute
            }
        }
    }

    suspend fun addTuitionClass(tuitionClass: TuitionClass): Long {
        return withContext(Dispatchers.IO) {
            val normalized = tuitionClass.copy(dateMillis = getStartOfDay(tuitionClass.dateMillis))
            val id = dao.insertClass(normalized)
            scheduleClassReminders(normalized.copy(id = id))
            recalculateDailyPerformance(normalized.dateMillis)
            id
        }
    }

    suspend fun updateTuitionClass(tuitionClass: TuitionClass) {
        withContext(Dispatchers.IO) {
            val normalized = tuitionClass.copy(dateMillis = getStartOfDay(tuitionClass.dateMillis))
            dao.updateClass(normalized)
            scheduleClassReminders(normalized)
            recalculateDailyPerformance(normalized.dateMillis)
        }
    }

    suspend fun deleteTuitionClass(tuitionClass: TuitionClass) {
        withContext(Dispatchers.IO) {
            dao.deleteClass(tuitionClass)
            cancelClassReminders(tuitionClass)
            recalculateDailyPerformance(tuitionClass.dateMillis)
        }
    }

    suspend fun addRecurringWeeklyClasses(
        baseClass: TuitionClass,
        selectedDays: List<Int>, // 1=Mon .. 7=Sun
        endDateMillis: Long
    ) {
        withContext(Dispatchers.IO) {
            val cal = Calendar.getInstance()
            cal.timeInMillis = getStartOfDay(baseClass.dateMillis)
            val endCal = Calendar.getInstance().apply { timeInMillis = getStartOfDay(endDateMillis) }

            val classesToInsert = mutableListOf<TuitionClass>()

            while (cal.timeInMillis <= endCal.timeInMillis) {
                // Calendar.DAY_OF_WEEK: Sun=1, Mon=2 ... Sat=7
                val calDay = cal.get(Calendar.DAY_OF_WEEK)
                val isoDay = if (calDay == Calendar.SUNDAY) 7 else calDay - 1

                if (selectedDays.contains(isoDay)) {
                    classesToInsert.add(
                        baseClass.copy(
                            id = 0,
                            dateMillis = cal.timeInMillis,
                            isRecurring = true,
                            recurringDays = selectedDays.joinToString(","),
                            recurringEndDateMillis = endDateMillis
                        )
                    )
                }
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }

            if (classesToInsert.isNotEmpty()) {
                dao.insertClasses(classesToInsert)
            }
        }
    }

    // Homework Management
    suspend fun addHomework(homework: Homework): Long {
        return withContext(Dispatchers.IO) {
            val id = dao.insertHomework(homework)
            recalculateDailyPerformance(getStartOfDay(System.currentTimeMillis()))
            id
        }
    }

    suspend fun updateHomework(homework: Homework) {
        withContext(Dispatchers.IO) {
            dao.updateHomework(homework)
            recalculateDailyPerformance(getStartOfDay(System.currentTimeMillis()))
        }
    }

    suspend fun deleteHomework(homework: Homework) {
        withContext(Dispatchers.IO) {
            dao.deleteHomework(homework)
            recalculateDailyPerformance(getStartOfDay(System.currentTimeMillis()))
        }
    }

    // Notes Management
    suspend fun addNote(note: ClassNote): Long {
        return withContext(Dispatchers.IO) {
            val id = dao.insertNote(note)
            recalculateDailyPerformance(getStartOfDay(note.dateMillis))
            id
        }
    }

    suspend fun deleteNote(note: ClassNote) {
        withContext(Dispatchers.IO) {
            dao.deleteNote(note)
            recalculateDailyPerformance(getStartOfDay(note.dateMillis))
        }
    }

    // Study Sessions & Live Focus Tracking
    suspend fun saveCompletedStudySession(session: StudySession): Long {
        return withContext(Dispatchers.IO) {
            val today = getStartOfDay(session.startTimeMillis)
            val id = dao.insertStudySession(session.copy(sessionDateMillis = today))
            recalculateDailyPerformance(today)
            id
        }
    }

    suspend fun saveEmergencyBreak(record: EmergencyBreakRecord): Long {
        return withContext(Dispatchers.IO) {
            dao.insertEmergencyBreak(record)
        }
    }

    // Habits & Pentagon Tracker
    fun getHabitForDate(dateMillis: Long): Flow<HabitRecord?> {
        return dao.getHabitForDate(getStartOfDay(dateMillis))
    }

    suspend fun updateHabit(habit: HabitRecord) {
        withContext(Dispatchers.IO) {
            val normalized = habit.copy(dateMillis = getStartOfDay(habit.dateMillis))
            dao.insertHabit(normalized)
            recalculateDailyPerformance(normalized.dateMillis)
        }
    }

    // Performance Calculations (Real Recorded Data ONLY - No Fabrications)
    fun getPerformanceForDate(dateMillis: Long): Flow<DailyPerformance?> {
        return dao.getPerformanceForDate(getStartOfDay(dateMillis))
    }

    suspend fun recalculateDailyPerformance(dateMillis: Long): DailyPerformance {
        return withContext(Dispatchers.IO) {
            val normalizedDate = getStartOfDay(dateMillis)

            // 1. Classes on this day
            val classes = dao.getClassesForDateSync(normalizedDate)
            val scheduledCount = classes.size
            val attendedCount = classes.count { it.attended || it.status == "Completed" }
            val missedCount = classes.count { it.status == "Missed" }

            // 2. Study Sessions on this day
            val sessions = dao.getStudySessionsForDateSync(normalizedDate)
            var totalStudySec = 0
            var focusSec = 0
            var chatGptSec = 0
            var breakSec = 0
            var distractionCount = 0
            var emergencyBreaksCount = 0
            var totalFocusRatingSum = 0

            sessions.forEach { s ->
                totalStudySec += s.actualDurationSeconds
                focusSec += s.focusDurationSeconds
                chatGptSec += s.chatGptDurationSeconds
                breakSec += s.breakDurationSeconds
                distractionCount += s.distractionEventsCount
                emergencyBreaksCount += s.breaksUsed
                if (s.focusRating > 0) totalFocusRatingSum += s.focusRating
            }

            val totalStudyMins = totalStudySec / 60
            val focusMins = focusSec / 60
            val chatGptMins = chatGptSec / 60
            val breakMins = breakSec / 60

            // 3. Homework Completed on this date
            val allHw = dao.getPendingHomework().firstOrNull() ?: emptyList()
            val allHwComplete = dao.getAllHomework().firstOrNull() ?: emptyList()
            val hwCompletedToday = allHwComplete.count {
                it.isCompleted && it.completedAtMillis != null && getStartOfDay(it.completedAtMillis) == normalizedDate
            }
            val hwPending = allHw.size

            // 4. Notes created on this date
            val allNotesList = dao.getAllNotes().firstOrNull() ?: emptyList()
            val notesToday = allNotesList.filter { getStartOfDay(it.dateMillis) == normalizedDate }
            val pagesWrittenToday = notesToday.sumOf { it.pagesCount }

            // 5. Habits for today
            val habit = dao.getHabitForDateSync(normalizedDate)

            // Calculate consecutive streak days up to yesterday + today
            val streak = calculateConsistencyStreak(normalizedDate)

            // Transparent Performance Scoring Formula (Max 100 points)
            // A. Attendance (20 pts): Attended / Scheduled classes (default 20 if no classes scheduled)
            val attendanceScore = if (scheduledCount > 0) {
                ((attendedCount.toFloat() / scheduledCount) * 20).roundToInt().coerceIn(0, 20)
            } else 20

            // B. Study Time (20 pts): Based on achieving 120 planned minutes or planned sessions
            val plannedTargetMins = 120
            val studyTimeScore = ((totalStudyMins.toFloat() / plannedTargetMins) * 20).roundToInt().coerceIn(0, 20)

            // C. Homework (20 pts): Ratio of completed homework or active progress
            val totalHwToday = hwCompletedToday + hwPending
            val homeworkScore = if (totalHwToday > 0) {
                ((hwCompletedToday.toFloat() / totalHwToday) * 20).roundToInt().coerceIn(0, 20)
            } else 20

            // D. Focus (20 pts): Ratio of focus time to total study time minus distraction penalties
            val focusRatio = if (totalStudySec > 0) focusSec.toFloat() / totalStudySec else 1f
            val distractionPenalty = (distractionCount * 2) + emergencyBreaksCount
            val focusScore = ((focusRatio * 20) - distractionPenalty).roundToInt().coerceIn(0, 20)

            // E. Consistency (20 pts): Consecutive academic days streak (e.g., 4 pts per day up to 5 days = 20)
            val consistencyScore = (streak * 4).coerceIn(0, 20)

            val overallScore = attendanceScore + studyTimeScore + homeworkScore + focusScore + consistencyScore

            val formulaExplanation = "Score Formula (100 pts max):\n" +
                    "• Attendance: $attendanceScore/20 (Attended: $attendedCount/$scheduledCount)\n" +
                    "• Study Time: $studyTimeScore/20 ($totalStudyMins min vs $plannedTargetMins min goal)\n" +
                    "• Homework: $homeworkScore/20 (Done: $hwCompletedToday, Pending: $hwPending)\n" +
                    "• Focus: $focusScore/20 (${focusRatio * 100}% focus ratio, $distractionCount distractions)\n" +
                    "• Consistency: $consistencyScore/20 ($streak days consecutive streak)"

            val performance = DailyPerformance(
                dateMillis = normalizedDate,
                overallScore = overallScore,
                attendanceScore = attendanceScore,
                studyTimeScore = studyTimeScore,
                homeworkScore = homeworkScore,
                focusScore = focusScore,
                consistencyScore = consistencyScore,
                totalStudyMinutes = totalStudyMins,
                focusMinutes = focusMins,
                chatGptMinutes = chatGptMins,
                breakMinutes = breakMins,
                distractionEvents = distractionCount,
                emergencyBreaksCount = emergencyBreaksCount,
                classesScheduled = scheduledCount,
                classesAttended = attendedCount,
                classesMissed = missedCount,
                homeworkCompletedCount = hwCompletedToday,
                homeworkPendingCount = hwPending,
                notesCreatedCount = notesToday.size,
                pagesWrittenCount = pagesWrittenToday,
                studyStreak = streak,
                formulaExplanation = formulaExplanation
            )

            dao.insertPerformance(performance)

            // Also update Habit record for the pentagon
            val updatedHabit = habit?.copy(
                tuitionAttendedCount = attendedCount,
                tuitionScheduledCount = scheduledCount,
                consistencyStreakDays = streak,
                homeworkCompletedToday = hwCompletedToday,
                homeworkPendingToday = hwPending,
                overallProgressPercent = calculateHabitProgressPercent(
                    habit?.exerciseCompleted ?: false,
                    attendedCount, scheduledCount,
                    streak,
                    hwCompletedToday, hwPending,
                    habit?.meditationCompleted ?: false
                )
            ) ?: HabitRecord(
                dateMillis = normalizedDate,
                tuitionAttendedCount = attendedCount,
                tuitionScheduledCount = scheduledCount,
                consistencyStreakDays = streak,
                homeworkCompletedToday = hwCompletedToday,
                homeworkPendingToday = hwPending,
                overallProgressPercent = calculateHabitProgressPercent(
                    false,
                    attendedCount, scheduledCount,
                    streak,
                    hwCompletedToday, hwPending,
                    false
                )
            )
            dao.insertHabit(updatedHabit)

            performance
        }
    }

    private fun calculateHabitProgressPercent(
        exercise: Boolean,
        tuitionAttended: Int, tuitionScheduled: Int,
        streak: Int,
        hwDone: Int, hwPending: Int,
        meditation: Boolean
    ): Int {
        var completed = 0
        if (exercise) completed++
        if (tuitionScheduled == 0 || tuitionAttended >= tuitionScheduled) completed++
        if (streak > 0) completed++
        if (hwPending == 0 || hwDone > 0) completed++
        if (meditation) completed++
        return (completed * 20).coerceIn(0, 100)
    }

    private suspend fun calculateConsistencyStreak(currentDateMillis: Long): Int {
        var streak = 0
        val oneDay = 24 * 60 * 60 * 1000L
        var checkDate = currentDateMillis

        // Check if today has academic activity
        val todaySessions = dao.getStudySessionsForDateSync(checkDate)
        val todayClasses = dao.getClassesForDateSync(checkDate)
        if (todaySessions.isNotEmpty() || todayClasses.any { it.attended }) {
            streak++
        }

        // Loop backwards
        for (i in 1..30) {
            checkDate -= oneDay
            val sessions = dao.getStudySessionsForDateSync(checkDate)
            val classes = dao.getClassesForDateSync(checkDate)
            val hadActivity = sessions.isNotEmpty() || classes.any { it.attended }
            if (hadActivity) {
                streak++
            } else {
                break
            }
        }
        return streak
    }

    // Daily Performance Comparison
    suspend fun getDailyComparison(todayMillis: Long): PerformanceComparison {
        return withContext(Dispatchers.IO) {
            val todayMidnight = getStartOfDay(todayMillis)
            val yesterdayMidnight = todayMidnight - 24 * 60 * 60 * 1000L

            val todayPerf = dao.getPerformanceForDateSync(todayMidnight)
                ?: recalculateDailyPerformance(todayMidnight)
            val yesterdayPerf = dao.getPerformanceForDateSync(yesterdayMidnight)

            val todayScore = todayPerf.overallScore
            val yesterdayScore = yesterdayPerf?.overallScore ?: 0

            val percentChange = if (yesterdayScore > 0) {
                (((todayScore - yesterdayScore).toFloat() / yesterdayScore) * 100)
            } else {
                null // Handled safely, first recorded day or yesterday was 0
            }

            val improved = mutableListOf<String>()
            val declined = mutableListOf<String>()
            val attention = mutableListOf<String>()

            if (yesterdayPerf != null) {
                if (todayPerf.focusMinutes > yesterdayPerf.focusMinutes) {
                    improved.add("Focus time increased compared with yesterday (+${todayPerf.focusMinutes - yesterdayPerf.focusMinutes} mins)")
                } else if (todayPerf.focusMinutes < yesterdayPerf.focusMinutes) {
                    declined.add("Focus time decreased compared with yesterday (-${yesterdayPerf.focusMinutes - todayPerf.focusMinutes} mins)")
                }

                if (todayPerf.classesAttended > yesterdayPerf.classesAttended) {
                    improved.add("Class attendance improved (${todayPerf.classesAttended} vs ${yesterdayPerf.classesAttended})")
                }

                if (todayPerf.distractionEvents < yesterdayPerf.distractionEvents) {
                    improved.add("Distraction events reduced (${todayPerf.distractionEvents} vs ${yesterdayPerf.distractionEvents})")
                } else if (todayPerf.distractionEvents > yesterdayPerf.distractionEvents) {
                    declined.add("Distractions increased (${todayPerf.distractionEvents} events)")
                    attention.add("Block high-distraction apps during active tuition hours")
                }
            } else {
                improved.add("First tracked day! Keep up the momentum")
            }

            if (todayPerf.classesMissed > 0) {
                attention.add("${todayPerf.classesMissed} tuition class(es) marked missed today")
            }
            if (todayPerf.homeworkPendingCount > 2) {
                attention.add("${todayPerf.homeworkPendingCount} pending homework assignments due soon")
            }

            PerformanceComparison(
                todayScore = todayScore,
                yesterdayScore = yesterdayScore,
                percentChange = percentChange,
                todayStudyMinutes = todayPerf.totalStudyMinutes,
                todayFocusMinutes = todayPerf.focusMinutes,
                todayChatGptMinutes = todayPerf.chatGptMinutes,
                improvedList = improved,
                declinedList = declined,
                attentionList = attention
            )
        }
    }

    // Reminders scheduling with AlarmManager
    private fun scheduleClassReminders(tuitionClass: TuitionClass) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val cal = Calendar.getInstance()
        cal.timeInMillis = tuitionClass.dateMillis
        cal.set(Calendar.HOUR_OF_DAY, tuitionClass.startTimeMinute / 60)
        cal.set(Calendar.MINUTE, tuitionClass.startTimeMinute % 60)
        cal.set(Calendar.SECOND, 0)

        val classStartMillis = cal.timeInMillis
        val reminderTimeMillis = classStartMillis - (15 * 60 * 1000L) // 15 mins before
        val focusModeStartMillis = classStartMillis - (5 * 60 * 1000L) // 5 mins before

        val timeStr = String.format(
            Locale.US, "%02d:%02d",
            tuitionClass.startTimeMinute / 60,
            tuitionClass.startTimeMinute % 60
        )

        // Class reminder alarm
        if (reminderTimeMillis > System.currentTimeMillis()) {
            val reminderIntent = Intent(context, TuitionAlarmReceiver::class.java).apply {
                action = TuitionAlarmReceiver.ACTION_TUITION_REMINDER
                putExtra("class_id", tuitionClass.id)
                putExtra("subject_name", tuitionClass.subjectName)
                putExtra("start_time_str", timeStr)
                putExtra("minutes_before", 15)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                tuitionClass.id.toInt(),
                reminderIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTimeMillis, pi)
                    } else {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, reminderTimeMillis, pi)
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTimeMillis, pi)
                }
            } catch (_: SecurityException) {}
        }

        // Pre-class Focus Mode alarm
        if (focusModeStartMillis > System.currentTimeMillis()) {
            val focusIntent = Intent(context, TuitionAlarmReceiver::class.java).apply {
                action = TuitionAlarmReceiver.ACTION_FOCUS_MODE_START
                putExtra("session_title", "${tuitionClass.subjectName} Class Focus")
            }
            val piFocus = PendingIntent.getBroadcast(
                context,
                tuitionClass.id.toInt() + 50000,
                focusIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                alarmManager.set(AlarmManager.RTC_WAKEUP, focusModeStartMillis, piFocus)
            } catch (_: SecurityException) {}
        }
    }

    private fun cancelClassReminders(tuitionClass: TuitionClass) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val reminderIntent = Intent(context, TuitionAlarmReceiver::class.java).apply {
            action = TuitionAlarmReceiver.ACTION_TUITION_REMINDER
        }
        val pi = PendingIntent.getBroadcast(
            context,
            tuitionClass.id.toInt(),
            reminderIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) alarmManager.cancel(pi)
    }

    // Data Export in JSON and CSV formats
    suspend fun exportDataAsJson(): String {
        return withContext(Dispatchers.IO) {
            val root = JSONObject()
            val classes = dao.getAllClasses().firstOrNull() ?: emptyList()
            val sessions = dao.getAllStudySessions().firstOrNull() ?: emptyList()
            val homework = dao.getAllHomework().firstOrNull() ?: emptyList()
            val notes = dao.getAllNotes().firstOrNull() ?: emptyList()
            val performance = dao.getRecentPerformance().firstOrNull() ?: emptyList()

            val classesArr = JSONArray()
            classes.forEach {
                classesArr.put(JSONObject().apply {
                    put("subject", it.subjectName)
                    put("teacher", it.teacherName)
                    put("dateMillis", it.dateMillis)
                    put("startTimeMinute", it.startTimeMinute)
                    put("endTimeMinute", it.endTimeMinute)
                    put("status", it.status)
                    put("attended", it.attended)
                })
            }
            root.put("classes", classesArr)

            val sessionsArr = JSONArray()
            sessions.forEach {
                sessionsArr.put(JSONObject().apply {
                    put("subject", it.subjectName)
                    put("task", it.taskName)
                    put("focusDurationSec", it.focusDurationSeconds)
                    put("chatGptDurationSec", it.chatGptDurationSeconds)
                    put("distractionEvents", it.distractionEventsCount)
                    put("breaksUsed", it.breaksUsed)
                })
            }
            root.put("study_sessions", sessionsArr)

            val hwArr = JSONArray()
            homework.forEach {
                hwArr.put(JSONObject().apply {
                    put("title", it.title)
                    put("subject", it.subjectName)
                    put("isCompleted", it.isCompleted)
                    put("deadlineMillis", it.deadlineMillis)
                })
            }
            root.put("homework", hwArr)

            val notesArr = JSONArray()
            notes.forEach {
                notesArr.put(JSONObject().apply {
                    put("subject", it.subjectName)
                    put("title", it.title)
                    put("pages", it.pagesCount)
                    put("dateMillis", it.dateMillis)
                })
            }
            root.put("notes", notesArr)

            val perfArr = JSONArray()
            performance.forEach {
                perfArr.put(JSONObject().apply {
                    put("dateMillis", it.dateMillis)
                    put("score", it.overallScore)
                    put("focusMinutes", it.focusMinutes)
                    put("totalStudyMinutes", it.totalStudyMinutes)
                    put("chatGptMinutes", it.chatGptMinutes)
                })
            }
            root.put("performance", perfArr)

            root.toString(2)
        }
    }

    suspend fun exportDataAsCsv(): String {
        return withContext(Dispatchers.IO) {
            val sb = StringBuilder()
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

            sb.append("=== TUITION CLASSES ===\n")
            sb.append("Date,Subject,Teacher,StartTime,EndTime,Status,Attended\n")
            val classes = dao.getAllClasses().firstOrNull() ?: emptyList()
            classes.forEach {
                val d = sdf.format(Date(it.dateMillis))
                val st = "${it.startTimeMinute / 60}:${String.format("%02d", it.startTimeMinute % 60)}"
                val et = "${it.endTimeMinute / 60}:${String.format("%02d", it.endTimeMinute % 60)}"
                sb.append("$d,\"${it.subjectName}\",\"${it.teacherName}\",$st,$et,${it.status},${it.attended}\n")
            }

            sb.append("\n=== STUDY SESSIONS ===\n")
            sb.append("Subject,Task,FocusSeconds,ChatGPTSeconds,BreakSeconds,Distractions\n")
            val sessions = dao.getAllStudySessions().firstOrNull() ?: emptyList()
            sessions.forEach {
                sb.append("\"${it.subjectName}\",\"${it.taskName}\",${it.focusDurationSeconds},${it.chatGptDurationSeconds},${it.breakDurationSeconds},${it.distractionEventsCount}\n")
            }

            sb.append("\n=== HOMEWORK ===\n")
            sb.append("Title,Subject,Deadline,Status\n")
            val homework = dao.getAllHomework().firstOrNull() ?: emptyList()
            homework.forEach {
                val dl = sdf.format(Date(it.deadlineMillis))
                sb.append("\"${it.title}\",\"${it.subjectName}\",$dl,${if (it.isCompleted) "Completed" else "Pending"}\n")
            }

            sb.toString()
        }
    }

    suspend fun toggleDistractionApp(packageName: String, enabled: Boolean) {
        withContext(Dispatchers.IO) {
            dao.updateDistractionAppStatus(packageName, enabled)
        }
    }

    suspend fun addDistractionApp(app: DistractionApp) {
        withContext(Dispatchers.IO) {
            dao.insertDistractionApp(app)
        }
    }

    suspend fun deleteDistractionApp(app: DistractionApp) {
        withContext(Dispatchers.IO) {
            dao.deleteDistractionApp(app)
        }
    }

    suspend fun updateSettings(settings: UserSettings) {
        withContext(Dispatchers.IO) {
            dao.insertUserSettings(settings)
        }
    }

    companion object {
        fun getStartOfDay(timeMillis: Long): Long {
            val cal = Calendar.getInstance()
            cal.timeInMillis = timeMillis
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            return cal.timeInMillis
        }
    }
}

data class PerformanceComparison(
    val todayScore: Int,
    val yesterdayScore: Int,
    val percentChange: Float?, // null if yesterday is 0
    val todayStudyMinutes: Int,
    val todayFocusMinutes: Int,
    val todayChatGptMinutes: Int,
    val improvedList: List<String>,
    val declinedList: List<String>,
    val attentionList: List<String>
)
