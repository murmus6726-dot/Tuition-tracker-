package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val teacherName: String = "",
    val colorHex: String = "#4338CA",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tuition_classes")
data class TuitionClass(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long = 0,
    val subjectName: String,
    val teacherName: String = "",
    val dateMillis: Long, // Midnight timestamp of the class date
    val startTimeMinute: Int, // Minute of day (e.g. 480 for 8:00 AM)
    val endTimeMinute: Int,   // Minute of day (e.g. 540 for 9:00 AM)
    val notes: String = "",
    val isRecurring: Boolean = false,
    val recurringDays: String = "", // e.g. "1,3,5" for Mon, Wed, Fri (1=Mon..7=Sun)
    val recurringEndDateMillis: Long? = null,
    val status: String = "Upcoming", // "Upcoming", "Starting Soon", "In Progress", "Completed", "Missed", "Partially Completed"
    val pagesOfNotes: Int = 0,
    val attendanceRecorded: Boolean = false,
    val attended: Boolean = false,
    val focusRating: Int = 0, // 1 to 5
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long? = null,
    val homeworkId: Long? = null,
    val subjectName: String,
    val taskName: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long = 0,
    val plannedDurationMinutes: Int,
    val actualDurationSeconds: Int = 0,
    val focusDurationSeconds: Int = 0,
    val breakDurationSeconds: Int = 0,
    val chatGptDurationSeconds: Int = 0,
    val otherStudyAppsDurationSeconds: Int = 0,
    val distractionEventsCount: Int = 0,
    val breaksUsed: Int = 0,
    val focusRating: Int = 0,
    val isCompleted: Boolean = false,
    val sessionDateMillis: Long = 0 // midnight millis
)

@Entity(tableName = "emergency_breaks")
data class EmergencyBreakRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val breakNumber: Int, // 1, 2, 3
    val startTimeMillis: Long,
    val endTimeMillis: Long = 0,
    val durationSeconds: Int = 0
)

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val subjectName: String,
    val classId: Long? = null,
    val deadlineMillis: Long,
    val notes: String = "",
    val isCompleted: Boolean = false,
    val manualPriority: String? = null, // "HIGH", "MEDIUM", "LOW" or null
    val completedAtMillis: Long? = null,
    val attachmentUris: String = "", // comma-separated or json URIs
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "class_notes")
data class ClassNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val classId: Long? = null,
    val subjectName: String,
    val title: String,
    val content: String = "",
    val pagesCount: Int = 1,
    val dateMillis: Long,
    val attachmentUris: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
data class HabitRecord(
    @PrimaryKey val dateMillis: Long, // Midnight timestamp
    val exerciseCompleted: Boolean = false,
    val exerciseNotes: String = "",
    val tuitionAttendedCount: Int = 0,
    val tuitionScheduledCount: Int = 0,
    val consistencyStreakDays: Int = 0,
    val homeworkCompletedToday: Int = 0,
    val homeworkPendingToday: Int = 0,
    val meditationCompleted: Boolean = false,
    val meditationDurationMinutes: Int = 0,
    val overallProgressPercent: Int = 0
)

@Entity(tableName = "daily_performance")
data class DailyPerformance(
    @PrimaryKey val dateMillis: Long, // Midnight timestamp
    val overallScore: Int = 0, // 0..100
    val attendanceScore: Int = 0, // 0..20
    val studyTimeScore: Int = 0,  // 0..20
    val homeworkScore: Int = 0,   // 0..20
    val focusScore: Int = 0,      // 0..20
    val consistencyScore: Int = 0,// 0..20
    val totalStudyMinutes: Int = 0,
    val focusMinutes: Int = 0,
    val chatGptMinutes: Int = 0,
    val breakMinutes: Int = 0,
    val distractionEvents: Int = 0,
    val emergencyBreaksCount: Int = 0,
    val classesScheduled: Int = 0,
    val classesAttended: Int = 0,
    val classesMissed: Int = 0,
    val homeworkCompletedCount: Int = 0,
    val homeworkPendingCount: Int = 0,
    val notesCreatedCount: Int = 0,
    val pagesWrittenCount: Int = 0,
    val studyStreak: Int = 0,
    val formulaExplanation: String = ""
)

@Entity(tableName = "distraction_apps")
data class DistractionApp(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isEnabled: Boolean = true,
    val isAllowedStudyApp: Boolean = false,
    val usageSecondsToday: Long = 0L
)

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val reminderMinutesBeforeClass: Int = 15,
    val voiceAnnouncementEnabled: Boolean = true,
    val preClassFocusMinutes: Int = 5,
    val emergencyBreaksLimit: Int = 3,
    val emergencyBreakMaxMinutes: Int = 5,
    val dailyStudyGoalMinutes: Int = 120,
    val homeworkReminderHoursBefore: Int = 24
)
