package com.example.service

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings

data class AppUsageResult(
    val chatGptSeconds: Long,
    val otherStudySeconds: Long,
    val distractionAppsDetected: List<String>,
    val totalForegroundSeconds: Long
)

object UsageTrackerService {

    // Common package name for ChatGPT
    val CHATGPT_PACKAGES = listOf("com.openai.chatgpt", "com.chatgpt.android")

    // Common default study apps
    val DEFAULT_STUDY_PACKAGES = setOf(
        "com.google.android.calculator",
        "com.android.calculator2",
        "com.sec.android.app.popupcalculator",
        "com.google.android.apps.docs",
        "com.adobe.reader",
        "com.google.android.keep",
        "com.microsoft.office.onenote",
        "com.notion.id"
    )

    // Common distraction app packages
    val DEFAULT_DISTRACTION_PACKAGES = listOf(
        "com.google.android.youtube",
        "com.instagram.android",
        "com.facebook.katana",
        "com.zhiliaoapp.musically", // TikTok
        "com.snapchat.android",
        "com.twitter.android",
        "com.meesho.supply",       // Meesho shopping
        "com.amazon.mShop.android.shopping",
        "com.flipkart.android"
    )

    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings(context: Context) {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    /**
     * Queries usage events between [startMillis] and [endMillis].
     * Measures exact foreground time for ChatGPT, allowed study apps, and detects distraction app usage.
     */
    fun querySessionUsage(
        context: Context,
        startMillis: Long,
        endMillis: Long,
        distractionPackages: Set<String>,
        allowedStudyPackages: Set<String>
    ): AppUsageResult {
        if (!hasUsageStatsPermission(context)) {
            return AppUsageResult(0L, 0L, emptyList(), 0L)
        }

        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return AppUsageResult(0L, 0L, emptyList(), 0L)

        val usageEvents = usageStatsManager.queryEvents(startMillis, endMillis)
        val event = UsageEvents.Event()

        val foregroundTimes = mutableMapOf<String, Long>()
        val currentOpenTime = mutableMapOf<String, Long>()
        val distractionsFound = mutableSetOf<String>()

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            val pkg = event.packageName ?: continue
            val time = event.timeStamp

            when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> {
                    currentOpenTime[pkg] = time
                    if (distractionPackages.contains(pkg)) {
                        distractionsFound.add(pkg)
                    }
                }
                UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED -> {
                    val openedAt = currentOpenTime.remove(pkg)
                    if (openedAt != null && time > openedAt) {
                        val duration = (time - openedAt) / 1000
                        foregroundTimes[pkg] = (foregroundTimes[pkg] ?: 0L) + duration
                    }
                }
            }
        }

        // Account for apps still open at endMillis
        currentOpenTime.forEach { (pkg, openTime) ->
            if (endMillis > openTime) {
                val duration = (endMillis - openTime) / 1000
                foregroundTimes[pkg] = (foregroundTimes[pkg] ?: 0L) + duration
            }
        }

        var chatGptSec = 0L
        var otherStudySec = 0L
        var totalSec = 0L

        foregroundTimes.forEach { (pkg, sec) ->
            totalSec += sec
            if (CHATGPT_PACKAGES.contains(pkg)) {
                chatGptSec += sec
            } else if (allowedStudyPackages.contains(pkg) || DEFAULT_STUDY_PACKAGES.contains(pkg)) {
                otherStudySec += sec
            }
        }

        return AppUsageResult(
            chatGptSeconds = chatGptSec,
            otherStudySeconds = otherStudySec,
            distractionAppsDetected = distractionsFound.toList(),
            totalForegroundSeconds = totalSec
        )
    }
}
