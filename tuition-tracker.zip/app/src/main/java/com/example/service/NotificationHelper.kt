package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

object NotificationHelper {

    const val CHANNEL_TUITION_REMINDERS = "tuition_reminders"
    const val CHANNEL_FOCUS_MODE = "focus_mode"
    const val CHANNEL_HOMEWORK = "homework_reminders"
    const val CHANNEL_POST_CLASS = "post_class_review"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val tuitionChannel = NotificationChannel(
                CHANNEL_TUITION_REMINDERS,
                "Tuition Class Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminders before scheduled tuition classes"
                enableVibration(true)
            }

            val focusChannel = NotificationChannel(
                CHANNEL_FOCUS_MODE,
                "Focus Mode & Emergency Breaks",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Focus countdown and emergency break alerts"
                enableVibration(true)
            }

            val homeworkChannel = NotificationChannel(
                CHANNEL_HOMEWORK,
                "Homework Deadlines",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders for pending homework and deadlines"
            }

            val postClassChannel = NotificationChannel(
                CHANNEL_POST_CLASS,
                "Post-Class Review & Notes",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Post-class review and note-taking prompts"
            }

            notificationManager.createNotificationChannels(
                listOf(tuitionChannel, focusChannel, homeworkChannel, postClassChannel)
            )
        }
    }

    fun showTuitionReminder(
        context: Context,
        classId: Long,
        subjectName: String,
        startTimeStr: String,
        minutesBefore: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "focus")
            putExtra("class_id", classId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            classId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_TUITION_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Tuition Class in $minutesBefore mins")
            .setContentText("Your $subjectName class is coming at $startTimeStr. Please get ready for the class.")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Your $subjectName class starts at $startTimeStr. Pre-class focus mode will activate shortly to help you prepare.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(classId.toInt(), notification)
        } catch (_: SecurityException) {
            // Permission not granted on Android 13+
        }
    }

    fun showFocusModeStarting(context: Context, sessionTitle: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "focus")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_FOCUS_MODE)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Focus Mode Activated")
            .setContentText("$sessionTitle: Stay focused and avoid distractions!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(2001, notification)
        } catch (_: SecurityException) {}
    }

    fun showBreakEndingAlert(context: Context, remainingBreaks: Int) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "focus")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2002,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_FOCUS_MODE)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Emergency Break Ended")
            .setContentText("Focus session resumed automatically. Breaks remaining: $remainingBreaks/3")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(2002, notification)
        } catch (_: SecurityException) {}
    }

    fun showHomeworkReminder(context: Context, homeworkId: Long, title: String, subject: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "homework")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            homeworkId.toInt() + 10000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_HOMEWORK)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("Homework Reminder: $subject")
            .setContentText("Your $subject homework \"$title\" is pending.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(homeworkId.toInt() + 10000, notification)
        } catch (_: SecurityException) {}
    }

    fun showPostClassPrompt(context: Context, classId: Long, subject: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "review")
            putExtra("class_id", classId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            classId.toInt() + 20000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_POST_CLASS)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Class Completed: $subject")
            .setContentText("How was your class? Tap to complete your review and record notes.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(classId.toInt() + 20000, notification)
        } catch (_: SecurityException) {}
    }
}
