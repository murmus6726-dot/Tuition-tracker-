package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = IndigoPrimaryDark,
    onPrimary = IndigoOnPrimaryDark,
    primaryContainer = IndigoPrimaryContainerDark,
    onPrimaryContainer = IndigoOnPrimaryContainerDark,
    secondary = SecondaryCyanDark,
    secondaryContainer = SecondaryCyanContainerDark,
    tertiary = TertiaryAmberDark,
    tertiaryContainer = TertiaryAmberContainerDark,
    background = AcademicDarkBackground,
    surface = AcademicDarkSurface,
    surfaceVariant = AcademicDarkCard,
    outline = AcademicDarkCardBorder,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF8FAFC)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = IndigoPrimary,
    onPrimary = IndigoOnPrimary,
    primaryContainer = IndigoPrimaryContainer,
    onPrimaryContainer = IndigoOnPrimaryContainer,
    secondary = SecondaryCyan,
    secondaryContainer = SecondaryCyanContainer,
    onSecondaryContainer = SecondaryOnCyanContainer,
    tertiary = TertiaryAmber,
    tertiaryContainer = TertiaryAmberContainer,
    onTertiaryContainer = TertiaryOnAmberContainer,
    background = AcademicBackground,
    surface = AcademicSurface,
    surfaceVariant = Color(0xFFF1F5F9),
    outline = AcademicCardBorder,
    onBackground = AcademicDark,
    onSurface = AcademicDark
  )

@Composable
fun TuitionTrackerTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use intentional academic color scheme
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  TuitionTrackerTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
