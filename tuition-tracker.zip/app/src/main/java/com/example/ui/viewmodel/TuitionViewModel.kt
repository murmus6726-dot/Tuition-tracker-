package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.TuitionApp
import com.example.data.model.*
import com.example.data.repository.PerformanceComparison
import com.example.data.repository.TuitionRepository
import com.example.service.NotificationHelper
import com.example.service.TtsManager
import com.example.service.UsageTrackerService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

enum class AppDestination {
    HOME,
    SCHEDULE,
    FOCUS,
    HOMEWORK,
    NOTES,
    CALENDAR,
    ANALYTICS,
    SETTINGS
}

data class ActiveFocusState(
    val isActive: Boolean = false,
    val isPaused: Boolean = false,
    val isOnEmergencyBreak: Boolean = false,
    val subjectName: String = "",
    val taskName: String = "",
    val linkedClassId: Long? = null,
    val linkedHomeworkId: Long? = null,
    val totalPlannedSeconds: Int = 3600,
    val remainingSeconds: Int = 3600,
    val focusSeconds: Int = 0,
    val breakSeconds: Int = 0,
    val currentBreakRemainingSeconds: Int = 300, // 5 minutes max
    val breaksUsed: Int = 0,
    val maxBreaks: Int = 3,
    val distractionCount: Int = 0,
    val chatGptSeconds: Int = 0,
    val otherStudySeconds: Int = 0,
    val sessionStartTimeMillis: Long = 0L,
    val lastDistractionAppName: String? = null
)

class TuitionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as TuitionApp).repository
    private val ttsManager = TtsManager(application)

    // Navigation
    private val _currentDestination = MutableStateFlow(AppDestination.HOME)
    val currentDestination: StateFlow<AppDestination> = _currentDestination.asStateFlow()

    fun navigateTo(destination: AppDestination) {
        _currentDestination.value = destination
    }

    // Repository Flows
    val subjects = repository.allSubjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allClasses = repository.allClasses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allHomework = repository.allHomework.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingHomework = repository.pendingHomework.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allNotes = repository.allNotes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allSessions = repository.allStudySessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val distractionApps = repository.allDistractionApps.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val userSettings = repository.userSettings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val recentPerformance = repository.recentPerformance.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Date for Calendar
    private val _selectedDateMillis = MutableStateFlow(TuitionRepository.getStartOfDay(System.currentTimeMillis()))
    val selectedDateMillis: StateFlow<Long> = _selectedDateMillis.asStateFlow()

    val selectedDateClasses = _selectedDateMillis.flatMapLatest { date ->
        repository.getClassesForDate(date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedDateHabit = _selectedDateMillis.flatMapLatest { date ->
        repository.getHabitForDate(date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedDatePerformance = _selectedDateMillis.flatMapLatest { date ->
        repository.getPerformanceForDate(date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Daily Performance Comparison
    private val _dailyComparison = MutableStateFlow<PerformanceComparison?>(null)
    val dailyComparison: StateFlow<PerformanceComparison?> = _dailyComparison.asStateFlow()

    // Active Focus Session State
    private val _focusState = MutableStateFlow(ActiveFocusState())
    val focusState: StateFlow<ActiveFocusState> = _focusState.asStateFlow()
    private var timerJob: Job? = null

    // Dialog & Flow States
    private val _showReviewDialog = MutableStateFlow<TuitionClass?>(null)
    val showReviewDialog: StateFlow<TuitionClass?> = _showReviewDialog.asStateFlow()

    private val _selectedHabitDetail = MutableStateFlow<String?>(null)
    val selectedHabitDetail: StateFlow<String?> = _selectedHabitDetail.asStateFlow()

    private val _permissionToExplain = MutableStateFlow<String?>(null)
    val permissionToExplain: StateFlow<String?> = _permissionToExplain.asStateFlow()

    private val _overlapWarning = MutableStateFlow<String?>(null)
    val overlapWarning: StateFlow<String?> = _overlapWarning.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfEmpty()
            refreshPerformanceComparison()
        }
    }

    fun setSelectedDate(dateMillis: Long) {
        _selectedDateMillis.value = TuitionRepository.getStartOfDay(dateMillis)
    }

    fun refreshPerformanceComparison() {
        viewModelScope.launch {
            val comparison = repository.getDailyComparison(System.currentTimeMillis())
            _dailyComparison.value = comparison
        }
    }

    // Class Management
    fun checkOverlapAndSaveClass(
        tuitionClass: TuitionClass,
        onOverlapFound: () -> Unit,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val overlaps = repository.checkClassOverlap(
                dateMillis = tuitionClass.dateMillis,
                startTimeMinute = tuitionClass.startTimeMinute,
                endTimeMinute = tuitionClass.endTimeMinute,
                excludeClassId = tuitionClass.id
            )
            if (overlaps) {
                _overlapWarning.value = "Two classes are scheduled at the same time. Do you want to continue?"
                onOverlapFound()
            } else {
                if (tuitionClass.id == 0L) {
                    repository.addTuitionClass(tuitionClass)
                } else {
                    repository.updateTuitionClass(tuitionClass)
                }
                refreshPerformanceComparison()
                onSuccess()
            }
        }
    }

    fun forceSaveClass(tuitionClass: TuitionClass, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (tuitionClass.id == 0L) {
                repository.addTuitionClass(tuitionClass)
            } else {
                repository.updateTuitionClass(tuitionClass)
            }
            _overlapWarning.value = null
            refreshPerformanceComparison()
            onSuccess()
        }
    }

    fun saveRecurringClasses(
        baseClass: TuitionClass,
        selectedDays: List<Int>,
        endDateMillis: Long,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.addRecurringWeeklyClasses(baseClass, selectedDays, endDateMillis)
            refreshPerformanceComparison()
            onSuccess()
        }
    }

    fun deleteClass(tuitionClass: TuitionClass) {
        viewModelScope.launch {
            repository.deleteTuitionClass(tuitionClass)
            refreshPerformanceComparison()
        }
    }

    fun markClassAttendance(tuitionClass: TuitionClass, attended: Boolean) {
        viewModelScope.launch {
            val updated = tuitionClass.copy(
                attended = attended,
                attendanceRecorded = true,
                status = if (attended) "Completed" else "Missed"
            )
            repository.updateTuitionClass(updated)
            refreshPerformanceComparison()
        }
    }

    // Homework Management
    fun saveHomework(homework: Homework, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (homework.id == 0L) {
                repository.addHomework(homework)
            } else {
                repository.updateHomework(homework)
            }
            refreshPerformanceComparison()
            onSuccess()
        }
    }

    fun toggleHomeworkCompletion(homework: Homework) {
        viewModelScope.launch {
            val isNowCompleted = !homework.isCompleted
            val updated = homework.copy(
                isCompleted = isNowCompleted,
                completedAtMillis = if (isNowCompleted) System.currentTimeMillis() else null
            )
            repository.updateHomework(updated)
            refreshPerformanceComparison()
        }
    }

    fun deleteHomework(homework: Homework) {
        viewModelScope.launch {
            repository.deleteHomework(homework)
            refreshPerformanceComparison()
        }
    }

    // Notes Management
    fun saveNote(note: ClassNote, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addNote(note)
            refreshPerformanceComparison()
            onSuccess()
        }
    }

    fun deleteNote(note: ClassNote) {
        viewModelScope.launch {
            repository.deleteNote(note)
            refreshPerformanceComparison()
        }
    }

    // Focus Mode & Timer Management
    fun startFocusSession(
        subjectName: String,
        taskName: String,
        durationMinutes: Int = 60,
        linkedClassId: Long? = null,
        linkedHomeworkId: Long? = null
    ) {
        val totalSec = durationMinutes * 60
        _focusState.value = ActiveFocusState(
            isActive = true,
            isPaused = false,
            isOnEmergencyBreak = false,
            subjectName = subjectName,
            taskName = taskName,
            linkedClassId = linkedClassId,
            linkedHomeworkId = linkedHomeworkId,
            totalPlannedSeconds = totalSec,
            remainingSeconds = totalSec,
            focusSeconds = 0,
            breakSeconds = 0,
            breaksUsed = 0,
            distractionCount = 0,
            chatGptSeconds = 0,
            otherStudySeconds = 0,
            sessionStartTimeMillis = System.currentTimeMillis()
        )

        NotificationHelper.showFocusModeStarting(getApplication(), "$subjectName - $taskName")
        startTimerLoop()
        _currentDestination.value = AppDestination.FOCUS
    }

    private fun startTimerLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_focusState.value.isActive) {
                delay(1000)
                val current = _focusState.value
                if (current.isPaused) continue

                if (current.isOnEmergencyBreak) {
                    val breakRem = current.currentBreakRemainingSeconds - 1
                    val breakElapsed = current.breakSeconds + 1
                    if (breakRem <= 0) {
                        // Break finished, automatically resume focus mode!
                        NotificationHelper.showBreakEndingAlert(
                            getApplication(),
                            current.maxBreaks - current.breaksUsed
                        )
                        _focusState.value = current.copy(
                            isOnEmergencyBreak = false,
                            breakSeconds = breakElapsed,
                            currentBreakRemainingSeconds = 300
                        )
                    } else {
                        _focusState.value = current.copy(
                            breakSeconds = breakElapsed,
                            currentBreakRemainingSeconds = breakRem
                        )
                    }
                } else {
                    // Regular focus counting
                    val rem = (current.remainingSeconds - 1).coerceAtLeast(0)
                    val focusSec = current.focusSeconds + 1

                    // Real Usage check every 10 seconds if permitted
                    var chatGptSec = current.chatGptSeconds
                    var otherSec = current.otherStudySeconds
                    var distractions = current.distractionCount
                    var lastDistraction: String? = current.lastDistractionAppName

                    if (focusSec % 10 == 0) {
                        val usage = checkSessionAppUsage(current.sessionStartTimeMillis)
                        if (usage.chatGptSeconds > 0) {
                            chatGptSec = usage.chatGptSeconds.toInt()
                        }
                        if (usage.otherStudySeconds > 0) {
                            otherSec = usage.otherStudySeconds.toInt()
                        }
                        if (usage.distractionAppsDetected.isNotEmpty()) {
                            distractions += usage.distractionAppsDetected.size
                            lastDistraction = usage.distractionAppsDetected.first()
                        }
                    }

                    _focusState.value = current.copy(
                        remainingSeconds = rem,
                        focusSeconds = focusSec,
                        chatGptSeconds = chatGptSec,
                        otherStudySeconds = otherSec,
                        distractionCount = distractions,
                        lastDistractionAppName = lastDistraction
                    )

                    if (rem <= 0) {
                        // Session completed
                        endFocusSession()
                        break
                    }
                }
            }
        }
    }

    fun takeEmergencyBreak() {
        val current = _focusState.value
        if (!current.isActive || current.isOnEmergencyBreak || current.breaksUsed >= current.maxBreaks) {
            return
        }

        val newBreaksUsed = current.breaksUsed + 1
        _focusState.value = current.copy(
            isOnEmergencyBreak = true,
            breaksUsed = newBreaksUsed,
            currentBreakRemainingSeconds = 300 // 5 minutes max
        )

        viewModelScope.launch {
            repository.saveEmergencyBreak(
                EmergencyBreakRecord(
                    sessionId = current.linkedClassId ?: System.currentTimeMillis(),
                    breakNumber = newBreaksUsed,
                    startTimeMillis = System.currentTimeMillis(),
                    durationSeconds = 300
                )
            )
        }
    }

    fun resumeFromBreakEarly() {
        val current = _focusState.value
        if (current.isOnEmergencyBreak) {
            _focusState.value = current.copy(
                isOnEmergencyBreak = false,
                currentBreakRemainingSeconds = 300
            )
        }
    }

    fun pauseOrResumeFocus() {
        val current = _focusState.value
        _focusState.value = current.copy(isPaused = !current.isPaused)
    }

    fun addManualDistractionEvent(appName: String) {
        val current = _focusState.value
        _focusState.value = current.copy(
            distractionCount = current.distractionCount + 1,
            lastDistractionAppName = appName
        )
    }

    fun endFocusSession(focusRating: Int = 4) {
        val current = _focusState.value
        timerJob?.cancel()
        _focusState.value = current.copy(isActive = false)

        viewModelScope.launch {
            val actualDuration = current.focusSeconds + current.breakSeconds
            val session = StudySession(
                classId = current.linkedClassId,
                homeworkId = current.linkedHomeworkId,
                subjectName = current.subjectName,
                taskName = current.taskName,
                startTimeMillis = current.sessionStartTimeMillis,
                endTimeMillis = System.currentTimeMillis(),
                plannedDurationMinutes = current.totalPlannedSeconds / 60,
                actualDurationSeconds = actualDuration,
                focusDurationSeconds = current.focusSeconds,
                breakDurationSeconds = current.breakSeconds,
                chatGptDurationSeconds = current.chatGptSeconds,
                otherStudyAppsDurationSeconds = current.otherStudySeconds,
                distractionEventsCount = current.distractionCount,
                breaksUsed = current.breaksUsed,
                focusRating = focusRating,
                isCompleted = true,
                sessionDateMillis = TuitionRepository.getStartOfDay(current.sessionStartTimeMillis)
            )
            repository.saveCompletedStudySession(session)

            // If linked to class, show post-class review prompt
            if (current.linkedClassId != null) {
                val tuitionClass = repository.getClassesForDateSync(current.sessionStartTimeMillis)
                    .find { it.id == current.linkedClassId }
                _showReviewDialog.value = tuitionClass
            }
            refreshPerformanceComparison()
        }
    }

    private fun checkSessionAppUsage(startMillis: Long): com.example.service.AppUsageResult {
        val context = getApplication<TuitionApp>()
        val distractionPkgs = distractionApps.value
            .filter { it.isEnabled && !it.isAllowedStudyApp }
            .map { it.packageName }
            .toSet()
        val studyPkgs = distractionApps.value
            .filter { it.isAllowedStudyApp }
            .map { it.packageName }
            .toSet()

        return UsageTrackerService.querySessionUsage(
            context = context,
            startMillis = startMillis,
            endMillis = System.currentTimeMillis(),
            distractionPackages = distractionPkgs,
            allowedStudyPackages = studyPkgs
        )
    }

    // Post-Class Review
    fun openPostClassReview(tuitionClass: TuitionClass) {
        _showReviewDialog.value = tuitionClass
    }

    fun dismissReviewDialog() {
        _showReviewDialog.value = null
    }

    fun submitPostClassReview(
        tuitionClass: TuitionClass,
        attended: Boolean,
        pagesWritten: Int,
        focusRating: Int,
        homeworkDone: Boolean
    ) {
        viewModelScope.launch {
            val updated = tuitionClass.copy(
                attended = attended,
                attendanceRecorded = true,
                pagesOfNotes = pagesWritten,
                focusRating = focusRating,
                status = if (attended) "Completed" else "Missed"
            )
            repository.updateTuitionClass(updated)
            _showReviewDialog.value = null
            refreshPerformanceComparison()
        }
    }

    // Habits & Pentagon Interaction
    fun openHabitDetail(habitName: String) {
        _selectedHabitDetail.value = habitName
    }

    fun closeHabitDetail() {
        _selectedHabitDetail.value = null
    }

    fun updateExerciseHabit(completed: Boolean, notes: String) {
        viewModelScope.launch {
            val date = _selectedDateMillis.value
            val current = selectedDateHabit.value ?: HabitRecord(dateMillis = date)
            repository.updateHabit(current.copy(exerciseCompleted = completed, exerciseNotes = notes))
            refreshPerformanceComparison()
        }
    }

    fun updateMeditationHabit(completed: Boolean, durationMins: Int) {
        viewModelScope.launch {
            val date = _selectedDateMillis.value
            val current = selectedDateHabit.value ?: HabitRecord(dateMillis = date)
            repository.updateHabit(
                current.copy(
                    meditationCompleted = completed,
                    meditationDurationMinutes = durationMins
                )
            )
            refreshPerformanceComparison()
        }
    }

    // Distraction Apps
    fun toggleDistractionApp(packageName: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleDistractionApp(packageName, enabled)
        }
    }

    fun addCustomDistractionApp(name: String, pkg: String, isAllowedStudy: Boolean) {
        viewModelScope.launch {
            repository.addDistractionApp(
                DistractionApp(
                    packageName = pkg,
                    appName = name,
                    isEnabled = true,
                    isAllowedStudyApp = isAllowedStudy
                )
            )
        }
    }

    // Settings
    fun updateUserSettings(settings: UserSettings) {
        viewModelScope.launch {
            repository.updateSettings(settings)
        }
    }

    // Voice Announcement preview
    fun speakVoiceAnnouncement(subjectName: String) {
        val text = "Your $subjectName class is coming. Please get ready for the class."
        ttsManager.speak(text)
    }

    // Permissions explanation dialog
    fun showPermissionExplanation(permKey: String) {
        _permissionToExplain.value = permKey
    }

    fun dismissPermissionExplanation() {
        _permissionToExplain.value = null
    }

    // Data Export
    suspend fun getExportData(format: String): String {
        return if (format.uppercase() == "CSV") {
            repository.exportDataAsCsv()
        } else {
            repository.exportDataAsJson()
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        ttsManager.shutdown()
    }
}
