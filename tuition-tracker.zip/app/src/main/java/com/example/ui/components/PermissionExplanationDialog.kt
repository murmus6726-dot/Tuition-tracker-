package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

@Composable
fun PermissionExplanationDialog(
    permissionType: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val (title, icon, explanation, whatItDoes, whatItNeverDoes) = when (permissionType) {
        "USAGE_STATS" -> PermissionInfo(
            title = "Usage Access Permission",
            icon = Icons.Default.QueryStats,
            explanation = "Tuition Tracker uses Android's UsageStatsManager to track your actual study tools (like ChatGPT) and measure distraction apps during Focus Mode.",
            whatItDoes = "• Tracks ChatGPT foreground research time in real seconds\n• Detects if distraction apps are opened during active tuition focus sessions",
            whatItNeverDoes = "• NEVER reads your chats, prompts, or messages\n• NEVER accesses your personal accounts, passwords, or data\n• NEVER operates without your permission"
        )
        "EXACT_ALARM" -> PermissionInfo(
            title = "Exact Alarms Permission",
            icon = Icons.Default.Alarm,
            explanation = "Allows Tuition Tracker to ring precisely 15 minutes before your scheduled tuition classes so you never miss a class.",
            whatItDoes = "• Wakes device on time for scheduled tuition classes and pre-class focus",
            whatItNeverDoes = "• Does not drain battery or run continuously in the background"
        )
        "CAMERA" -> PermissionInfo(
            title = "Camera Permission",
            icon = Icons.Default.CameraAlt,
            explanation = "Allows you to capture photos of handwritten tuition class notes and textbook homework assignments directly into your local database.",
            whatItDoes = "• Takes photos of blackboard, whiteboard, and homework sheets",
            whatItNeverDoes = "• Never uploads your photos to any remote server; all photos stay 100% on your device"
        )
        else -> PermissionInfo(
            title = "Notification Permission",
            icon = Icons.Default.Notifications,
            explanation = "Allows Tuition Tracker to display pre-class alerts and emergency break timers.",
            whatItDoes = "• Shows class alerts and focus countdowns",
            whatItNeverDoes = "• Never sends promotional or spam notifications"
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("permission_explanation_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(28.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "PRIVACY & SECURITY",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Text(
                    text = explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "WHAT THIS DOES:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = whatItDoes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "WHAT THIS NEVER DOES:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = whatItNeverDoes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Text("Grant Permission")
                    }
                }
            }
        }
    }
}

private data class PermissionInfo(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val explanation: String,
    val whatItDoes: String,
    val whatItNeverDoes: String
)
