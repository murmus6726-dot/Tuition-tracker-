package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val IndigoPrimary = Color(0xFF4338CA)
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoPrimaryContainer = Color(0xFFE0E7FF)
val IndigoOnPrimaryContainer = Color(0xFF1E1B4B)

val SecondaryCyan = Color(0xFF0284C7)
val SecondaryCyanContainer = Color(0xFFE0F2FE)
val SecondaryOnCyanContainer = Color(0xFF082F49)

val TertiaryAmber = Color(0xFFD97706)
val TertiaryAmberContainer = Color(0xFFFEF3C7)
val TertiaryOnAmberContainer = Color(0xFF78350F)

val AcademicDark = Color(0xFF0F172A)
val AcademicCard = Color(0xFFFFFFFF)
val AcademicCardBorder = Color(0xFFE2E8F0)
val AcademicBackground = Color(0xFFF8FAFC)
val AcademicSurface = Color(0xFFFFFFFF)

// Dark Theme Palette
val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoOnPrimaryDark = Color(0xFF1E1B4B)
val IndigoPrimaryContainerDark = Color(0xFF312E81)
val IndigoOnPrimaryContainerDark = Color(0xFFE0E7FF)

val SecondaryCyanDark = Color(0xFF38BDF8)
val SecondaryCyanContainerDark = Color(0xFF0369A1)

val TertiaryAmberDark = Color(0xFFFBBF24)
val TertiaryAmberContainerDark = Color(0xFF78350F)

val AcademicDarkBackground = Color(0xFF0B0F19)
val AcademicDarkSurface = Color(0xFF131B2E)
val AcademicDarkCard = Color(0xFF1E293B)
val AcademicDarkCardBorder = Color(0xFF334155)

// Status and Habit Accents
val HabitExercise = Color(0xFFEF4444)     // Crimson / Energy
val HabitTuition = Color(0xFF6366F1)      // Indigo / Academic
val HabitConsistency = Color(0xFFF59E0B)  // Golden Flame / Streak
val HabitHomework = Color(0xFF10B981)     // Emerald / Completed work
val HabitMeditation = Color(0xFF8B5CF6)   // Purple / Mindfulness
val ChatGPTAccent = Color(0xFF10A37F)     // Real OpenAI green for ChatGPT tracker
