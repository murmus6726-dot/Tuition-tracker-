package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyPerformance
import com.example.data.model.StudySession
import com.example.data.model.TuitionClass
import com.example.ui.theme.ChatGPTAccent
import com.example.ui.viewmodel.TuitionViewModel

@Composable
fun AnalyticsScreen(
    viewModel: TuitionViewModel,
    modifier: Modifier = Modifier
) {
    val allClasses by viewModel.allClasses.collectAsState()
    val allSessions by viewModel.allSessions.collectAsState()
    val recentPerformance by viewModel.recentPerformance.collectAsState()
    val comparison by viewModel.dailyComparison.collectAsState()

    val totalClasses = allClasses.size
    val attendedClasses = allClasses.count { it.attended || it.status == "Completed" }
    val attendanceRate = if (totalClasses > 0) (attendedClasses * 100) / totalClasses else 100

    val totalStudySeconds = remember(allSessions) {
        allSessions.sumOf { it.actualDurationSeconds }
    }
    val totalFocusSeconds = remember(allSessions) {
        allSessions.sumOf { it.focusDurationSeconds }
    }
    val totalChatGptSeconds = remember(allSessions) {
        allSessions.sumOf { it.chatGptDurationSeconds }
    }
    val totalDistractions = remember(allSessions) {
        allSessions.sumOf { it.distractionEventsCount }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "ACADEMIC INTELLIGENCE",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Analytics & Consistency",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black)
                )
                Text(
                    text = "Calculated exclusively from real recorded study sessions and classes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 4 Primary Metric Tiles
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricAnalyticsTile(
                    title = "Attendance Rate",
                    value = "$attendanceRate%",
                    subtitle = "$attendedClasses/$totalClasses Classes",
                    icon = Icons.Default.School,
                    modifier = Modifier.weight(1f)
                )
                MetricAnalyticsTile(
                    title = "Total Study Time",
                    value = "${totalStudySeconds / 3600}h ${(totalStudySeconds % 3600) / 60}m",
                    subtitle = "${allSessions.size} Sessions",
                    icon = Icons.Default.Timer,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricAnalyticsTile(
                    title = "ChatGPT Research",
                    value = "${totalChatGptSeconds / 60} mins",
                    subtitle = "UsageStats Recorded",
                    icon = Icons.Default.AutoAwesome,
                    iconColor = ChatGPTAccent,
                    modifier = Modifier.weight(1f)
                )
                MetricAnalyticsTile(
                    title = "Distraction Ratio",
                    value = "$totalDistractions events",
                    subtitle = "${if (totalStudySeconds > 0) (totalFocusSeconds * 100) / totalStudySeconds else 100}% Focus Ratio",
                    icon = Icons.Default.Shield,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Daily Comparison Card
        if (comparison != null) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Today vs. Yesterday Comparison",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (comparison?.percentChange != null) {
                                val pos = comparison!!.percentChange!! >= 0
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (pos) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                                ) {
                                    Text(
                                        text = "${if (pos) "+" else ""}${String.format("%.1f", comparison!!.percentChange)}%",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (pos) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }

                        if (comparison!!.improvedList.isNotEmpty()) {
                            Text(
                                text = "IMPROVEMENTS:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            comparison!!.improvedList.forEach { Text(text = "• $it", style = MaterialTheme.typography.bodySmall) }
                        }

                        if (comparison!!.declinedList.isNotEmpty()) {
                            Text(
                                text = "AREAS REQUIRING ATTENTION:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.error
                            )
                            comparison!!.declinedList.forEach { Text(text = "• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }

        // Subject Study Time Distribution Chart
        item {
            SubjectDistributionCard(sessions = allSessions)
        }

        // Daily Performance Score Chart (Canvas bar chart)
        item {
            DailyScoreHistoryCard(recentPerformance = recentPerformance)
        }
    }
}

@Composable
fun MetricAnalyticsTile(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun SubjectDistributionCard(sessions: List<StudySession>) {
    // Group study time by subject
    val subjectMinutes = remember(sessions) {
        val map = mutableMapOf<String, Int>()
        sessions.forEach { s ->
            map[s.subjectName] = (map[s.subjectName] ?: 0) + (s.actualDurationSeconds / 60)
        }
        map
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Subject Study Distribution",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            if (subjectMinutes.isEmpty()) {
                Text(
                    text = "Complete study sessions to generate subject time allocation.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val maxMinutes = subjectMinutes.values.maxOrNull()?.coerceAtLeast(1) ?: 1
                subjectMinutes.forEach { (subject, mins) ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = subject, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                            Text(text = "${mins}m", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        LinearProgressIndicator(
                            progress = { (mins.toFloat() / maxMinutes).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailyScoreHistoryCard(recentPerformance: List<DailyPerformance>) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Daily Performance Score History",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            val displayList = recentPerformance.take(7).reversed()
            if (displayList.isEmpty()) {
                Text(
                    text = "Scores will be plotted here daily as you attend tuition and study.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val primaryColor = MaterialTheme.colorScheme.primary
                val trackColor = MaterialTheme.colorScheme.surfaceVariant

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    val count = displayList.size
                    val spacing = size.width / (count.coerceAtLeast(1))
                    val barWidth = (spacing * 0.55f).coerceAtMost(36.dp.toPx())

                    for (i in displayList.indices) {
                        val score = displayList[i].overallScore.coerceIn(0, 100)
                        val barHeight = (score / 100f) * size.height * 0.85f
                        val x = i * spacing + (spacing - barWidth) / 2f
                        val y = size.height - barHeight

                        // Background track
                        drawRoundRect(
                            color = trackColor,
                            topLeft = Offset(x, 0f),
                            size = Size(barWidth, size.height),
                            cornerRadius = CornerRadius(8f, 8f)
                        )

                        // Score bar
                        drawRoundRect(
                            color = primaryColor,
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Previous Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "Today", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
