package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Homework
import com.example.data.model.Subject
import com.example.ui.viewmodel.TuitionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeworkScreen(
    viewModel: TuitionViewModel,
    modifier: Modifier = Modifier
) {
    val allHomework by viewModel.allHomework.collectAsState()
    val subjects by viewModel.subjects.collectAsState()

    var selectedFilter by remember { mutableStateOf("Pending") }
    var showAddDialog by remember { mutableStateOf(false) }
    var hwToEdit by remember { mutableStateOf<Homework?>(null) }

    val filteredHomework = remember(allHomework, selectedFilter) {
        when (selectedFilter) {
            "Pending" -> allHomework.filter { !it.isCompleted }
            "Completed" -> allHomework.filter { it.isCompleted }
            "High Priority" -> allHomework.filter { it.manualPriority == "HIGH" || (!it.isCompleted && it.deadlineMillis < System.currentTimeMillis() + 24 * 3600 * 1000) }
            else -> allHomework
        }
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    hwToEdit = null
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Homework") },
                text = { Text("New Homework") },
                modifier = Modifier
                    .padding(bottom = 64.dp)
                    .testTag("add_homework_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "ACADEMIC TASKS",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Homework Tracker",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black)
                )
            }

            // Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf("Pending", "High Priority", "Completed", "All")
                items(filters) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredHomework.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.AssignmentTurnedIn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No homework in this view",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "Tap '+ New Homework' to add assignments with deadlines.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredHomework) { hw ->
                        HomeworkItemCard(
                            homework = hw,
                            onToggleCompleted = { viewModel.toggleHomeworkCompletion(hw) },
                            onEdit = {
                                hwToEdit = hw
                                showAddDialog = true
                            },
                            onDelete = { viewModel.deleteHomework(hw) },
                            onStartFocus = {
                                viewModel.startFocusSession(
                                    subjectName = hw.subjectName,
                                    taskName = hw.title,
                                    durationMinutes = 45,
                                    linkedHomeworkId = hw.id
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditHomeworkDialog(
            homework = hwToEdit,
            subjects = subjects,
            onDismiss = { showAddDialog = false },
            onSave = { updatedHw ->
                viewModel.saveHomework(updatedHw) {
                    showAddDialog = false
                }
            }
        )
    }
}

@Composable
fun HomeworkItemCard(
    homework: Homework,
    onToggleCompleted: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onStartFocus: () -> Unit
) {
    val deadlineDate = remember(homework.deadlineMillis) {
        val sdf = SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.US)
        sdf.format(Date(homework.deadlineMillis))
    }

    val now = System.currentTimeMillis()
    val isOverdue = !homework.isCompleted && homework.deadlineMillis < now
    val isDueSoon = !homework.isCompleted && homework.deadlineMillis - now < 24 * 3600 * 1000L

    val priority = homework.manualPriority ?: if (isOverdue || isDueSoon) "HIGH" else "MEDIUM"

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(onClick = onToggleCompleted) {
                        Icon(
                            imageVector = if (homework.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Toggle Complete",
                            tint = if (homework.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = homework.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (homework.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = homework.subjectName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (priority) {
                        "HIGH" -> MaterialTheme.colorScheme.errorContainer
                        "MEDIUM" -> MaterialTheme.colorScheme.tertiaryContainer
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    }
                ) {
                    Text(
                        text = "$priority PRIORITY",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when (priority) {
                            "HIGH" -> MaterialTheme.colorScheme.onErrorContainer
                            "MEDIUM" -> MaterialTheme.colorScheme.onTertiaryContainer
                            else -> MaterialTheme.colorScheme.onSecondaryContainer
                        }
                    )
                }
            }

            if (homework.description.isNotEmpty()) {
                Text(
                    text = homework.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    Icons.Default.Schedule,
                    contentDescription = null,
                    tint = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (isOverdue) "Overdue: $deadlineDate" else "Due: $deadlineDate",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal,
                        color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!homework.isCompleted) {
                    OutlinedButton(
                        onClick = onStartFocus,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Focus Session")
                    }
                }

                OutlinedButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                }

                OutlinedButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun AddEditHomeworkDialog(
    homework: Homework?,
    subjects: List<Subject>,
    onDismiss: () -> Unit,
    onSave: (Homework) -> Unit
) {
    var title by remember { mutableStateOf(homework?.title ?: "") }
    var description by remember { mutableStateOf(homework?.description ?: "") }
    var subjectName by remember { mutableStateOf(homework?.subjectName ?: if (subjects.isNotEmpty()) subjects[0].name else "") }
    var notes by remember { mutableStateOf(homework?.notes ?: "") }
    var priority by remember { mutableStateOf(homework?.manualPriority ?: "MEDIUM") }
    var daysAhead by remember { mutableIntStateOf(1) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (homework == null) "New Homework Assignment" else "Edit Homework",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Assignment Title (e.g. Chapter 4 Practice)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("Subject Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Task Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(text = "Deadline Due In:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1 Day" to 1, "2 Days" to 2, "3 Days" to 3, "1 Week" to 7).forEach { (label, d) ->
                        FilterChip(
                            selected = daysAhead == d,
                            onClick = { daysAhead = d },
                            label = { Text(label) }
                        )
                    }
                }

                Text(text = "Priority Level:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("HIGH", "MEDIUM", "LOW").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Hints") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val deadline = System.currentTimeMillis() + (daysAhead * 24L * 3600 * 1000)
                            val item = (homework ?: Homework(
                                title = title.ifBlank { "Homework Task" },
                                subjectName = subjectName.ifBlank { "General Subject" },
                                deadlineMillis = deadline
                            )).copy(
                                title = title.ifBlank { "Homework Task" },
                                subjectName = subjectName.ifBlank { "General Subject" },
                                description = description,
                                notes = notes,
                                manualPriority = priority,
                                deadlineMillis = deadline
                            )
                            onSave(item)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
