package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TuitionClass
import com.example.ui.components.PentagonHabitTracker
import com.example.ui.components.PerformanceScoreBreakdownDialog
import com.example.ui.theme.ChatGPTAccent
import com.example.ui.theme.HabitTuition
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.TuitionViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    viewModel: TuitionViewModel,
    onNavigateTo: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedDateHabit by viewModel.selectedDateHabit.collectAsState()
    val todayClasses by viewModel.selectedDateClasses.collectAsState()
    val pendingHw by viewModel.pendingHomework.collectAsState()
    val performance by viewModel.selectedDatePerformance.collectAsState()
    val comparison by viewModel.dailyComparison.collectAsState()
    val focusState by viewModel.focusState.collectAsState()

    var showScoreDialog by remember { mutableStateOf(false) }

    val dateFormatted = remember {
        SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(Date())
    }

    if (showScoreDialog) {
        PerformanceScoreBreakdownDialog(
            performance = performance,
            comparison = comparison,
            onDismiss = { showScoreDialog = false }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 96.dp, start = 16.dp, end = 16.dp, top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Greeting
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = dateFormatted.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Tuition Tracker",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Never miss tuition, stay focused, track real study time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Active Focus Banner (if session is currently running)
        if (focusState.isActive) {
            item {
                ActiveFocusBanner(
                    focusState = focusState,
                    onClick = { onNavigateTo(AppDestination.FOCUS) }
                )
            }
        }

        // 2. Pentagon Habit Tracker Card
        item {
            PentagonHabitTracker(
                habitRecord = selectedDateHabit,
                onHabitSelected = { habitId ->
                    viewModel.openHabitDetail(habitId)
                }
            )
        }

        // 3. Daily Performance Score Card
        item {
            PerformanceSummaryCard(
                score = performance?.overallScore ?: 0,
                comparisonPercent = comparison?.percentChange,
                totalStudyMinutes = performance?.totalStudyMinutes ?: 0,
                focusMinutes = performance?.focusMinutes ?: 0,
                chatGptMinutes = performance?.chatGptMinutes ?: 0,
                onViewFormula = { showScoreDialog = true }
            )
        }

        // 4. Today's Tuition Schedule Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Tuition Classes",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = { onNavigateTo(AppDestination.SCHEDULE) }) {
                    Text("View Timetable")
                }
            }
        }

        if (todayClasses.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.EventAvailable,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "No tuition classes scheduled today",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "Enjoy your self-study session or schedule a class.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(todayClasses) { tuitionClass ->
                TuitionClassCard(
                    tuitionClass = tuitionClass,
                    onStartFocus = {
                        viewModel.startFocusSession(
                            subjectName = tuitionClass.subjectName,
                            taskName = "Tuition Class",
                            durationMinutes = (tuitionClass.endTimeMinute - tuitionClass.startTimeMinute).coerceAtLeast(30),
                            linkedClassId = tuitionClass.id
                        )
                    },
                    onOpenReview = {
                        viewModel.openPostClassReview(tuitionClass)
                    }
                )
            }
        }

        // 5. Quick Pending Homework
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pending Homework (${pendingHw.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = { onNavigateTo(AppDestination.HOMEWORK) }) {
                    Text("All Tasks")
                }
            }
        }

        if (pendingHw.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "All homework is complete! Keep up the momentum.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        } else {
            items(pendingHw.take(3)) { hw ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onNavigateTo(AppDestination.HOMEWORK) },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = hw.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = hw.subjectName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(onClick = { viewModel.toggleHomeworkCompletion(hw) }) {
                            Icon(
                                Icons.Default.CheckCircleOutline,
                                contentDescription = "Mark done",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveFocusBanner(
    focusState: com.example.ui.viewmodel.ActiveFocusState,
    onClick: () -> Unit
) {
    val remMins = focusState.remainingSeconds / 60
    val remSecs = focusState.remainingSeconds % 60

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("active_focus_banner"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (focusState.isOnEmergencyBreak) Icons.Default.Pause else Icons.Default.HourglassTop,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = if (focusState.isOnEmergencyBreak) "EMERGENCY BREAK ACTIVE" else "FOCUS SESSION IN PROGRESS",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = focusState.subjectName.ifEmpty { "Study Session" },
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Text(
                text = String.format("%02d:%02d", remMins, remSecs),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun PerformanceSummaryCard(
    score: Int,
    comparisonPercent: Float?,
    totalStudyMinutes: Int,
    focusMinutes: Int,
    chatGptMinutes: Int,
    onViewFormula: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("performance_summary_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "STUDY PERFORMANCE SCORE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.1.sp
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Real Calculated Metrics",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                TextButton(onClick = onViewFormula) {
                    Text("Formula Breakdown", style = MaterialTheme.typography.labelMedium)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "$score",
                        style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "/100",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                if (comparisonPercent != null) {
                    val positive = comparisonPercent >= 0
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (positive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = "${if (positive) "+" else ""}${String.format("%.1f", comparisonPercent)}% vs yesterday",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (positive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                StatMetric(
                    label = "Total Study",
                    value = "${totalStudyMinutes}m",
                    icon = Icons.Default.AccessTime
                )
                StatMetric(
                    label = "Focus Time",
                    value = "${focusMinutes}m",
                    icon = Icons.Default.FilterCenterFocus
                )
                StatMetric(
                    label = "ChatGPT Tool",
                    value = "${chatGptMinutes}m",
                    icon = Icons.Default.AutoAwesome,
                    color = ChatGPTAccent
                )
            }
        }
    }
}

@Composable
fun StatMetric(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color = MaterialTheme.colorScheme.primary
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun TuitionClassCard(
    tuitionClass: TuitionClass,
    onStartFocus: () -> Unit,
    onOpenReview: () -> Unit
) {
    val startHour = tuitionClass.startTimeMinute / 60
    val startMin = tuitionClass.startTimeMinute % 60
    val endHour = tuitionClass.endTimeMinute / 60
    val endMin = tuitionClass.endTimeMinute % 60

    val timeString = String.format(
        Locale.US,
        "%02d:%02d - %02d:%02d",
        startHour, startMin, endHour, endMin
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tuition_card_${tuitionClass.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = tuitionClass.subjectName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    if (tuitionClass.teacherName.isNotEmpty()) {
                        Text(
                            text = tuitionClass.teacherName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (tuitionClass.status) {
                        "Completed" -> MaterialTheme.colorScheme.primaryContainer
                        "Missed" -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    }
                ) {
                    Text(
                        text = tuitionClass.status,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when (tuitionClass.status) {
                            "Completed" -> MaterialTheme.colorScheme.onPrimaryContainer
                            "Missed" -> MaterialTheme.colorScheme.onErrorContainer
                            else -> MaterialTheme.colorScheme.onSecondaryContainer
                        }
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Schedule,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = timeString,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
            }

            if (tuitionClass.notes.isNotEmpty()) {
                Text(
                    text = tuitionClass.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onStartFocus,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Focus Mode")
                }

                Button(
                    onClick = onOpenReview,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (tuitionClass.attendanceRecorded) "Edit Review" else "Class Review")
                }
            }
        }
    }
}
