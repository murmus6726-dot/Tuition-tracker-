package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.DailyPerformance
import com.example.data.repository.PerformanceComparison

@Composable
fun PerformanceScoreBreakdownDialog(
    performance: DailyPerformance?,
    comparison: PerformanceComparison?,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("performance_score_breakdown_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PERFORMANCE ENGINE",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Transparent Score Formula",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider()

                // Overall Score Badge
                val score = performance?.overallScore ?: 0
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$score / 100",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Real Calculated Score",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (comparison?.percentChange != null) {
                        val isPositive = comparison.percentChange >= 0
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isPositive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                        ) {
                            Text(
                                text = "${if (isPositive) "+" else ""}${String.format("%.1f", comparison.percentChange)}% vs Yesterday",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isPositive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }

                // 5 Pillars Breakdown
                ScorePillarItem(
                    label = "Attendance",
                    points = performance?.attendanceScore ?: 0,
                    maxPoints = 20,
                    detail = "Attended ${performance?.classesAttended ?: 0}/${performance?.classesScheduled ?: 0} scheduled classes"
                )
                ScorePillarItem(
                    label = "Study Time",
                    points = performance?.studyTimeScore ?: 0,
                    maxPoints = 20,
                    detail = "${performance?.totalStudyMinutes ?: 0} mins logged vs 120 min target"
                )
                ScorePillarItem(
                    label = "Homework",
                    points = performance?.homeworkScore ?: 0,
                    maxPoints = 20,
                    detail = "${performance?.homeworkCompletedCount ?: 0} completed, ${performance?.homeworkPendingCount ?: 0} pending"
                )
                ScorePillarItem(
                    label = "Focus Ratio",
                    points = performance?.focusScore ?: 0,
                    maxPoints = 20,
                    detail = "${performance?.focusMinutes ?: 0}m focus, ${performance?.distractionEvents ?: 0} distractions"
                )
                ScorePillarItem(
                    label = "Consistency",
                    points = performance?.consistencyScore ?: 0,
                    maxPoints = 20,
                    detail = "${performance?.studyStreak ?: 0} consecutive study days"
                )

                // Comparison Highlights
                if (comparison != null) {
                    HorizontalDivider()
                    Text(
                        text = "Daily Performance Insights",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    if (comparison.improvedList.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "WHAT IMPROVED:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            comparison.improvedList.forEach { item ->
                                Text(text = "• $item", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (comparison.declinedList.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "WHAT DECLINED:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.error
                            )
                            comparison.declinedList.forEach { item ->
                                Text(text = "• $item", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (comparison.attentionList.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "AREAS REQUIRING ATTENTION:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            comparison.attentionList.forEach { item ->
                                Text(text = "• $item", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Got It")
                }
            }
        }
    }
}

@Composable
private fun ScorePillarItem(
    label: String,
    points: Int,
    maxPoints: Int,
    detail: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(
                text = "$points / $maxPoints pts",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
        }
        LinearProgressIndicator(
            progress = { (points.toFloat() / maxPoints).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
        Text(
            text = detail,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
