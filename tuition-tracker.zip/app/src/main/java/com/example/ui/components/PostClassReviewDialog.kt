package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TuitionClass

@Composable
fun PostClassReviewDialog(
    tuitionClass: TuitionClass,
    onDismiss: () -> Unit,
    onSubmit: (attended: Boolean, pagesWritten: Int, focusRating: Int, homeworkDone: Boolean) -> Unit
) {
    var attended by remember { mutableStateOf(true) }
    var pagesCountText by remember { mutableStateOf("2") }
    var focusRating by remember { mutableIntStateOf(4) }
    var homeworkCompleted by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("post_class_review_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "POST-CLASS REVIEW",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = tuitionClass.subjectName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider()

                // Q1: Did you attend the class?
                Text(
                    text = "1. Did you attend the class?",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilterChip(
                        selected = attended,
                        onClick = { attended = true },
                        label = { Text("Yes, Attended") },
                        leadingIcon = if (attended) {
                            { Icon(Icons.Default.Check, contentDescription = null) }
                        } else null
                    )
                    FilterChip(
                        selected = !attended,
                        onClick = { attended = false },
                        label = { Text("Missed Class") }
                    )
                }

                // Q2: How many pages of notes did you make today?
                Text(
                    text = "2. How many pages of notes did you make today?",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                OutlinedTextField(
                    value = pagesCountText,
                    onValueChange = { pagesCountText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Pages of notes written") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Q3: How focused were you? (1 to 5 stars)
                Text(
                    text = "3. How focused were you? ($focusRating/5)",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (star in 1..5) {
                        Icon(
                            imageVector = if (star <= focusRating) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Star $star",
                            tint = if (star <= focusRating) Color(0xFFF59E0B) else MaterialTheme.colorScheme.outline,
                            modifier = Modifier
                                .size(36.dp)
                                .clickable { focusRating = star }
                                .padding(2.dp)
                        )
                    }
                }

                // Q4: Did you complete any homework?
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "4. Completed associated homework?",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Switch(
                        checked = homeworkCompleted,
                        onCheckedChange = { homeworkCompleted = it }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Skip")
                    }
                    Button(
                        onClick = {
                            val pages = pagesCountText.toIntOrNull() ?: 0
                            onSubmit(attended, pages, focusRating, homeworkCompleted)
                        },
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("Save Review")
                    }
                }
            }
        }
    }
}
