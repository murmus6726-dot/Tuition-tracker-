package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Subject
import com.example.data.model.TuitionClass
import com.example.ui.viewmodel.TuitionViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    viewModel: TuitionViewModel,
    modifier: Modifier = Modifier
) {
    val allClasses by viewModel.allClasses.collectAsState()
    val subjects by viewModel.subjects.collectAsState()
    val selectedDateMillis by viewModel.selectedDateMillis.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var classToEdit by remember { mutableStateOf<TuitionClass?>(null) }
    var overlapWarningClass by remember { mutableStateOf<TuitionClass?>(null) }

    // Group classes for the selected date
    val classesForSelectedDate = remember(allClasses, selectedDateMillis) {
        allClasses.filter { it.dateMillis == selectedDateMillis }
            .sortedBy { it.startTimeMinute }
    }

    // Days selector for the current week
    val currentWeekDays = remember {
        val list = mutableListOf<Long>()
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        for (i in 0..6) {
            val d = Calendar.getInstance().apply {
                timeInMillis = cal.timeInMillis
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            list.add(d.timeInMillis)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        list
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    classToEdit = null
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Class") },
                text = { Text("Add Class") },
                modifier = Modifier
                    .padding(bottom = 64.dp)
                    .testTag("add_class_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "TUITION SCHEDULE",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Weekly Timetable",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black)
                )
            }

            // Week Day Tabs (Mon - Sun)
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(currentWeekDays) { dateMillis ->
                    val cal = Calendar.getInstance().apply { timeInMillis = dateMillis }
                    val dayName = SimpleDateFormat("EEE", Locale.US).format(cal.time)
                    val dayNum = SimpleDateFormat("d", Locale.US).format(cal.time)
                    val isSelected = dateMillis == selectedDateMillis

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { viewModel.setSelectedDate(dateMillis) }
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = dayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = dayNum,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Classes list for selected date
            if (classesForSelectedDate.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No classes scheduled for this day",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "Tap '+ Add Class' to schedule a one-time or recurring class.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(classesForSelectedDate) { tuitionClass ->
                        ScheduleClassCard(
                            tuitionClass = tuitionClass,
                            onEdit = {
                                classToEdit = tuitionClass
                                showAddDialog = true
                            },
                            onDelete = {
                                viewModel.deleteClass(tuitionClass)
                            },
                            onToggleAttendance = {
                                viewModel.markClassAttendance(tuitionClass, !tuitionClass.attended)
                            },
                            onVoicePreview = {
                                viewModel.speakVoiceAnnouncement(tuitionClass.subjectName)
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog) {
        AddEditClassDialog(
            classToEdit = classToEdit,
            subjects = subjects,
            currentDateMillis = selectedDateMillis,
            onDismiss = { showAddDialog = false },
            onSave = { newClass, recurringDays, recurringEndDate ->
                viewModel.checkOverlapAndSaveClass(
                    tuitionClass = newClass,
                    onOverlapFound = {
                        overlapWarningClass = newClass
                    },
                    onSuccess = {
                        if (recurringDays.isNotEmpty() && recurringEndDate != null) {
                            viewModel.saveRecurringClasses(newClass, recurringDays, recurringEndDate) {}
                        }
                        showAddDialog = false
                    }
                )
            }
        )
    }

    // Overlap Warning Confirmation Dialog
    if (overlapWarningClass != null) {
        AlertDialog(
            onDismissRequest = { overlapWarningClass = null },
            title = { Text("Schedule Overlap Detected") },
            text = {
                Text("Two classes are scheduled at the same time. Do you want to continue?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        overlapWarningClass?.let {
                            viewModel.forceSaveClass(it) {
                                overlapWarningClass = null
                                showAddDialog = false
                            }
                        }
                    }
                ) {
                    Text("Continue Anyway")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { overlapWarningClass = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ScheduleClassCard(
    tuitionClass: TuitionClass,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleAttendance: () -> Unit,
    onVoicePreview: () -> Unit
) {
    val startHour = tuitionClass.startTimeMinute / 60
    val startMin = tuitionClass.startTimeMinute % 60
    val endHour = tuitionClass.endTimeMinute / 60
    val endMin = tuitionClass.endTimeMinute % 60

    val timeStr = String.format(Locale.US, "%02d:%02d - %02d:%02d", startHour, startMin, endHour, endMin)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = tuitionClass.subjectName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    if (tuitionClass.teacherName.isNotEmpty()) {
                        Text(
                            text = tuitionClass.teacherName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onVoicePreview) {
                        Icon(
                            Icons.Default.RecordVoiceOver,
                            contentDescription = "Preview Announcement",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Text(text = timeStr, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))

                if (tuitionClass.isRecurring) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = "Recurring",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            if (tuitionClass.notes.isNotEmpty()) {
                Text(
                    text = tuitionClass.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = tuitionClass.attended,
                    onClick = onToggleAttendance,
                    label = { Text(if (tuitionClass.attended) "Attended" else "Mark Attended") },
                    leadingIcon = if (tuitionClass.attended) {
                        { Icon(Icons.Default.Check, contentDescription = null) }
                    } else null
                )

                if (tuitionClass.pagesOfNotes > 0) {
                    Text(
                        text = "${tuitionClass.pagesOfNotes} pages recorded",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun AddEditClassDialog(
    classToEdit: TuitionClass?,
    subjects: List<Subject>,
    currentDateMillis: Long,
    onDismiss: () -> Unit,
    onSave: (TuitionClass, List<Int>, Long?) -> Unit
) {
    var subjectName by remember { mutableStateOf(classToEdit?.subjectName ?: if (subjects.isNotEmpty()) subjects[0].name else "") }
    var teacherName by remember { mutableStateOf(classToEdit?.teacherName ?: "") }
    var startHourText by remember { mutableStateOf((classToEdit?.startTimeMinute?.div(60) ?: 8).toString()) }
    var startMinText by remember { mutableStateOf((classToEdit?.startTimeMinute?.rem(60) ?: 0).toString()) }
    var endHourText by remember { mutableStateOf((classToEdit?.endTimeMinute?.div(60) ?: 9).toString()) }
    var endMinText by remember { mutableStateOf((classToEdit?.endTimeMinute?.rem(60) ?: 0).toString()) }
    var notes by remember { mutableStateOf(classToEdit?.notes ?: "") }
    var isRecurring by remember { mutableStateOf(classToEdit?.isRecurring ?: false) }
    val selectedDays = remember { mutableStateListOf<Int>() }

    val daysOfWeek = listOf("Mon" to 1, "Tue" to 2, "Wed" to 3, "Thu" to 4, "Fri" to 5, "Sat" to 6, "Sun" to 7)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (classToEdit == null) "Add Tuition Class" else "Edit Tuition Class",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                // Subject Name
                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("Subject (e.g. Financial Accounting)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Teacher
                OutlinedTextField(
                    value = teacherName,
                    onValueChange = { teacherName = it },
                    label = { Text("Teacher Name (e.g. Prof. Roberts)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Time fields
                Text(text = "Start Time (24h format)", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startHourText,
                        onValueChange = { startHourText = it },
                        label = { Text("Hour") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = startMinText,
                        onValueChange = { startMinText = it },
                        label = { Text("Min") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text(text = "End Time (24h format)", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = endHourText,
                        onValueChange = { endHourText = it },
                        label = { Text("Hour") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endMinText,
                        onValueChange = { endMinText = it },
                        label = { Text("Min") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Topics") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Recurring Setup
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Repeat Weekly", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isRecurring, onCheckedChange = { isRecurring = it })
                }

                if (isRecurring) {
                    Text(text = "Select Days:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        daysOfWeek.forEach { (name, dayInt) ->
                            val isSelected = selectedDays.contains(dayInt)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) selectedDays.remove(dayInt) else selectedDays.add(dayInt)
                                },
                                label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val startH = startHourText.toIntOrNull() ?: 8
                            val startM = startMinText.toIntOrNull() ?: 0
                            val endH = endHourText.toIntOrNull() ?: 9
                            val endM = endMinText.toIntOrNull() ?: 0

                            val startMinTotal = (startH * 60 + startM).coerceIn(0, 1439)
                            val endMinTotal = (endH * 60 + endM).coerceIn(startMinTotal + 15, 1440)

                            val newClass = (classToEdit ?: TuitionClass(
                                subjectName = subjectName.ifBlank { "General Subject" },
                                dateMillis = currentDateMillis,
                                startTimeMinute = startMinTotal,
                                endTimeMinute = endMinTotal
                            )).copy(
                                subjectName = subjectName.ifBlank { "General Subject" },
                                teacherName = teacherName,
                                startTimeMinute = startMinTotal,
                                endTimeMinute = endMinTotal,
                                notes = notes,
                                isRecurring = isRecurring
                            )

                            val endDate = if (isRecurring) currentDateMillis + (30L * 24 * 60 * 60 * 1000) else null
                            onSave(newClass, selectedDays.toList(), endDate)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
