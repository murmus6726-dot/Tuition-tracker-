package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HabitRecord
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class HabitItemData(
    val id: String,
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val isCompleted: Boolean,
    val dailyProgress: String,
    val weeklyProgress: String,
    val streakText: String,
    val accentColor: Color
)

@Composable
fun PentagonHabitTracker(
    habitRecord: HabitRecord?,
    onHabitSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val exerciseCompleted = habitRecord?.exerciseCompleted ?: false
    val tuitionScheduled = habitRecord?.tuitionScheduledCount ?: 0
    val tuitionAttended = habitRecord?.tuitionAttendedCount ?: 0
    val tuitionCompleted = tuitionScheduled == 0 || tuitionAttended >= tuitionScheduled
    val consistencyStreak = habitRecord?.consistencyStreakDays ?: 0
    val hwDone = habitRecord?.homeworkCompletedToday ?: 0
    val hwPending = habitRecord?.homeworkPendingToday ?: 0
    val hwCompleted = hwPending == 0 || hwDone > 0
    val meditationCompleted = habitRecord?.meditationCompleted ?: false
    val overallPercent = habitRecord?.overallProgressPercent ?: 0

    val habits = listOf(
        HabitItemData(
            id = "Exercise",
            name = "Exercise",
            icon = Icons.Default.FitnessCenter,
            isCompleted = exerciseCompleted,
            dailyProgress = if (exerciseCompleted) "Done" else "Pending",
            weeklyProgress = if (exerciseCompleted) "5/7 days" else "4/7 days",
            streakText = if (exerciseCompleted) "3 days" else "0 days",
            accentColor = HabitExercise
        ),
        HabitItemData(
            id = "Tuition",
            name = "Tuition",
            icon = Icons.Default.School,
            isCompleted = tuitionCompleted,
            dailyProgress = "$tuitionAttended/$tuitionScheduled attended",
            weeklyProgress = "Attended $tuitionAttended",
            streakText = "$consistencyStreak days",
            accentColor = HabitTuition
        ),
        HabitItemData(
            id = "Consistency",
            name = "Consistency",
            icon = Icons.Default.LocalFireDepartment,
            isCompleted = consistencyStreak > 0,
            dailyProgress = "$consistencyStreak day streak",
            weeklyProgress = "Target: 7d",
            streakText = "$consistencyStreak days",
            accentColor = HabitConsistency
        ),
        HabitItemData(
            id = "Homework",
            name = "Homework",
            icon = Icons.Default.MenuBook,
            isCompleted = hwCompleted,
            dailyProgress = "$hwDone done, $hwPending left",
            weeklyProgress = "$hwDone completed",
            streakText = if (hwDone > 0) "Active" else "Pending",
            accentColor = HabitHomework
        ),
        HabitItemData(
            id = "Meditation",
            name = "Meditation",
            icon = Icons.Default.SelfImprovement,
            isCompleted = meditationCompleted,
            dailyProgress = if (meditationCompleted) "${habitRecord?.meditationDurationMinutes ?: 10}m done" else "Pending",
            weeklyProgress = if (meditationCompleted) "4 sessions" else "3 sessions",
            streakText = if (meditationCompleted) "1 day" else "0 days",
            accentColor = HabitMeditation
        )
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("pentagon_habit_tracker_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PENTAGON HABIT TRACKER",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Daily Academic Discipline",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = "$overallPercent% Done",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pentagon Interactive Canvas
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                PentagonCanvas(
                    habits = habits,
                    overallPercent = overallPercent,
                    onSectionTapped = { habitIndex ->
                        if (habitIndex in habits.indices) {
                            onHabitSelected(habits[habitIndex].id)
                        } else {
                            onHabitSelected("Overall")
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5 Habit quick stats chips
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                habits.forEach { habit ->
                    HabitRowItem(
                        habit = habit,
                        onClick = { onHabitSelected(habit.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun PentagonCanvas(
    habits: List<HabitItemData>,
    overallPercent: Int,
    onSectionTapped: (Int) -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val centerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)
    val strokeColor = if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val centerX = size.width / 2f
                    val centerY = size.height / 2f
                    val dx = offset.x - centerX
                    val dy = offset.y - centerY
                    val dist = sqrt(dx * dx + dy * dy)
                    val rOuter = size.width.coerceAtMost(size.height) * 0.46f
                    val rInner = rOuter * 0.40f

                    if (dist < rInner) {
                        onSectionTapped(-1) // Center tapped
                    } else if (dist <= rOuter * 1.1f) {
                        // Angle from -pi to pi. Note: y is down
                        var angleDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                        // Convert so -90° (top) is the center of section 0 (-90 +- 36)
                        // Normalize angle to [0, 360) starting from -90 - 36 = -126
                        var shifted = angleDeg + 90f + 36f
                        while (shifted < 0) shifted += 360f
                        while (shifted >= 360) shifted -= 360f
                        val section = (shifted / 72f).toInt().coerceIn(0, 4)
                        onSectionTapped(section)
                    }
                }
            }
    ) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val rOuter = (size.width.coerceAtMost(size.height) / 2f) * 0.92f
        val rInner = rOuter * 0.40f

        // Vertices for Outer and Inner Pentagons
        val outerPoints = mutableListOf<Offset>()
        val innerPoints = mutableListOf<Offset>()

        for (i in 0 until 5) {
            val angle = (-90f + i * 72f) * (PI / 180f)
            val ox = centerX + rOuter * cos(angle).toFloat()
            val oy = centerY + rOuter * sin(angle).toFloat()
            outerPoints.add(Offset(ox, oy))

            val ix = centerX + rInner * cos(angle).toFloat()
            val iy = centerY + rInner * sin(angle).toFloat()
            innerPoints.add(Offset(ix, iy))
        }

        // Draw 5 Outer Trapezoidal Sections
        for (i in 0 until 5) {
            val next = (i + 1) % 5
            val habit = habits[i]
            val path = Path().apply {
                moveTo(innerPoints[i].x, innerPoints[i].y)
                lineTo(outerPoints[i].x, outerPoints[i].y)
                lineTo(outerPoints[next].x, outerPoints[next].y)
                lineTo(innerPoints[next].x, innerPoints[next].y)
                close()
            }

            // Fill color with subtle tint if completed
            val fillColor = if (habit.isCompleted) {
                habit.accentColor.copy(alpha = 0.35f)
            } else {
                habit.accentColor.copy(alpha = 0.08f)
            }

            drawPath(path, color = fillColor, style = Fill)
            drawPath(path, color = habit.accentColor.copy(alpha = if (habit.isCompleted) 0.9f else 0.4f), style = Stroke(width = 2.5f))
        }

        // Connecting radial dividing spokes
        for (i in 0 until 5) {
            drawLine(
                color = strokeColor,
                start = innerPoints[i],
                end = outerPoints[i],
                strokeWidth = 2f
            )
        }

        // Central Pentagon (Overall Progress)
        val centerPath = Path().apply {
            moveTo(innerPoints[0].x, innerPoints[0].y)
            for (i in 1 until 5) {
                lineTo(innerPoints[i].x, innerPoints[i].y)
            }
            close()
        }

        // Draw Central Area
        drawPath(
            centerPath,
            brush = Brush.radialGradient(
                colors = listOf(
                    IndigoPrimary.copy(alpha = 0.25f),
                    centerColor
                ),
                center = Offset(centerX, centerY),
                radius = rInner
            ),
            style = Fill
        )
        drawPath(
            centerPath,
            color = IndigoPrimary,
            style = Stroke(width = 3.5f)
        )
    }

    // Centered percentage text overlaid on canvas
    Box(
        modifier = Modifier
            .size(100.dp)
            .clip(CircleShape)
            .clickable { onSectionTapped(-1) },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "$overallPercent%",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp
                ),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "OVERALL",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    letterSpacing = 0.8.sp
                ),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun HabitRowItem(
    habit: HabitItemData,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("habit_row_${habit.id.lowercase()}"),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(habit.accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = habit.icon,
                        contentDescription = habit.name,
                        tint = habit.accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = habit.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = habit.dailyProgress,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (habit.isCompleted) habit.accentColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = habit.streakText,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (habit.isCompleted) habit.accentColor else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Icon(
                    imageVector = if (habit.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (habit.isCompleted) "Completed" else "Pending",
                    tint = if (habit.isCompleted) habit.accentColor else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
