package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.HabitRecord

@Composable
fun HabitDetailDialog(
    habitName: String,
    habitRecord: HabitRecord?,
    onDismiss: () -> Unit,
    onUpdateExercise: (Boolean, String) -> Unit,
    onUpdateMeditation: (Boolean, Int) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "HABIT DETAIL",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = habitName,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider()

                when (habitName) {
                    "Exercise" -> {
                        var isDone by remember { mutableStateOf(habitRecord?.exerciseCompleted ?: false) }
                        var notes by remember { mutableStateOf(habitRecord?.exerciseNotes ?: "") }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Mark Exercise Completed for Today", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = isDone, onCheckedChange = { isDone = it })
                        }
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Workout note (e.g. 20 min walk, stretching)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                onUpdateExercise(isDone, notes)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Exercise Status")
                        }
                    }

                    "Tuition" -> {
                        val attended = habitRecord?.tuitionAttendedCount ?: 0
                        val scheduled = habitRecord?.tuitionScheduledCount ?: 0
                        Text(
                            text = "Real Tuition Attendance Status",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "• Scheduled today: $scheduled\n• Attended today: $attended\n• Attendance Rate: ${if (scheduled > 0) "${(attended * 100) / scheduled}%" else "100% (Free Day)"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Class attendance is automatically tracked from your tuition timetable and post-class logs.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    "Consistency" -> {
                        val streak = habitRecord?.consistencyStreakDays ?: 0
                        Text(
                            text = "Academic Consistency Streak",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "🔥 $streak Consecutive Days of Real Study",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Consistency is calculated strictly from days with recorded tuition attendance, completed study sessions, or finished homework.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    "Homework" -> {
                        val done = habitRecord?.homeworkCompletedToday ?: 0
                        val pending = habitRecord?.homeworkPendingToday ?: 0
                        Text(
                            text = "Daily Homework Progress",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "• Completed today: $done\n• Pending assignments: $pending",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Complete your pending homework in the Homework Tracker to maintain a 100% habit rating.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    "Meditation" -> {
                        var isDone by remember { mutableStateOf(habitRecord?.meditationCompleted ?: false) }
                        var durationText by remember {
                            mutableStateOf((habitRecord?.meditationDurationMinutes ?: 10).toString())
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Mark Meditation Completed", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = isDone, onCheckedChange = { isDone = it })
                        }
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Duration (minutes)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                val mins = durationText.toIntOrNull() ?: 10
                                onUpdateMeditation(isDone, mins)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Meditation Status")
                        }
                    }

                    else -> {
                        val overall = habitRecord?.overallProgressPercent ?: 0
                        Text(
                            text = "Overall Habit Progress: $overall%",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Each habit contributes equally (20%) to your overall daily academic discipline pentagon score.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Close")
                }
            }
        }
    }
}
