package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.UsageTrackerService
import com.example.ui.components.PermissionExplanationDialog
import com.example.ui.theme.ChatGPTAccent
import com.example.ui.viewmodel.ActiveFocusState
import com.example.ui.viewmodel.TuitionViewModel

@Composable
fun FocusScreen(
    viewModel: TuitionViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusState by viewModel.focusState.collectAsState()
    val subjects by viewModel.subjects.collectAsState()
    val permissionToExplain by viewModel.permissionToExplain.collectAsState()

    var customSubject by remember { mutableStateOf("") }
    var customTask by remember { mutableStateOf("") }
    var selectedDuration by remember { mutableIntStateOf(60) }

    val hasUsagePermission = remember {
        UsageTrackerService.hasUsageStatsPermission(context)
    }

    if (permissionToExplain != null) {
        PermissionExplanationDialog(
            permissionType = permissionToExplain!!,
            onDismiss = { viewModel.dismissPermissionExplanation() },
            onConfirm = {
                viewModel.dismissPermissionExplanation()
                if (permissionToExplain == "USAGE_STATS") {
                    UsageTrackerService.openUsageAccessSettings(context)
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("focus_screen"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "FOCUS MODE & DISTRACTION BLOCKING",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (focusState.isActive) "Active Study Session" else "Start Focus Session",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black)
            )
        }

        if (focusState.isActive) {
            // Live Focus Dashboard
            ActiveFocusDashboard(
                state = focusState,
                onPauseResume = { viewModel.pauseOrResumeFocus() },
                onEmergencyBreak = { viewModel.takeEmergencyBreak() },
                onResumeFromBreak = { viewModel.resumeFromBreakEarly() },
                onEndSession = { viewModel.endFocusSession() },
                onExplainPermission = { viewModel.showPermissionExplanation("USAGE_STATS") },
                hasUsagePermission = hasUsagePermission
            )
        } else {
            // Setup new Focus Session
            FocusSetupCard(
                subjects = subjects.map { it.name },
                selectedSubject = customSubject,
                onSelectSubject = { customSubject = it },
                taskName = customTask,
                onTaskNameChange = { customTask = it },
                selectedDuration = selectedDuration,
                onSelectDuration = { selectedDuration = it },
                onStart = {
                    val subj = customSubject.ifBlank { if (subjects.isNotEmpty()) subjects[0].name else "General Study" }
                    val task = customTask.ifBlank { "Deep Work Session" }
                    viewModel.startFocusSession(
                        subjectName = subj,
                        taskName = task,
                        durationMinutes = selectedDuration
                    )
                },
                onPreClassFocus = {
                    val subj = customSubject.ifBlank { if (subjects.isNotEmpty()) subjects[0].name else "Tuition Class" }
                    viewModel.startFocusSession(
                        subjectName = subj,
                        taskName = "Pre-Class Focus Prep",
                        durationMinutes = 5
                    )
                },
                onExplainPermission = { viewModel.showPermissionExplanation("USAGE_STATS") },
                hasUsagePermission = hasUsagePermission
            )
        }
    }
}

@Composable
fun ActiveFocusDashboard(
    state: ActiveFocusState,
    onPauseResume: () -> Unit,
    onEmergencyBreak: () -> Unit,
    onResumeFromBreak: () -> Unit,
    onEndSession: () -> Unit,
    onExplainPermission: () -> Unit,
    hasUsagePermission: Boolean
) {
    val totalSec = state.totalPlannedSeconds.coerceAtLeast(1)
    val remSec = state.remainingSeconds
    val progress = (1f - (remSec.toFloat() / totalSec)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "timerProgress")

    val remMins = remSec / 60
    val remSecRemainder = remSec % 60

    val breakRem = state.currentBreakRemainingSeconds
    val breakMins = breakRem / 60
    val breakSecs = breakRem % 60

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (state.isOnEmergencyBreak) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Task info
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = state.subjectName,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = state.taskName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Circular Countdown Timer Display
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    progress = { if (state.isOnEmergencyBreak) (breakRem.toFloat() / 300f) else animatedProgress },
                    modifier = Modifier.fillMaxSize(),
                    strokeWidth = 10.dp,
                    color = if (state.isOnEmergencyBreak) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (state.isOnEmergencyBreak) {
                        Text(
                            text = "EMERGENCY BREAK",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = String.format("%02d:%02d", breakMins, breakSecs),
                            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = "Auto-resumes in 5m",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = if (state.isPaused) "PAUSED" else "REMAINING",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = String.format("%02d:%02d", remMins, remSecRemainder),
                            style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${state.focusSeconds / 60}m focus elapsed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Emergency Break Button & Status
            val breaksLeft = state.maxBreaks - state.breaksUsed
            if (state.isOnEmergencyBreak) {
                Button(
                    onClick = onResumeFromBreak,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Resume Focus Now")
                }
            } else {
                OutlinedButton(
                    onClick = onEmergencyBreak,
                    enabled = breaksLeft > 0 && !state.isPaused,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PauseCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (breaksLeft > 0) "Take Emergency Break (5m max) • $breaksLeft/3 Left"
                        else "Emergency Breaks Exhausted (0/3)"
                    )
                }
            }

            // Play / Pause and End Session Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onPauseResume,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (state.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (state.isPaused) "Resume" else "Pause")
                }

                Button(
                    onClick = onEndSession,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("End Session")
                }
            }
        }
    }

    // ChatGPT and Distraction App Live Tracking Cards
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ChatGPTAccent)
                    Text(
                        text = "ChatGPT Study Tracking",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ChatGPTAccent.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${state.chatGptSeconds / 60}m ${state.chatGptSeconds % 60}s logged",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = ChatGPTAccent
                    )
                }
            }

            Text(
                text = "Tuition Tracker tracks your active foreground ChatGPT usage to record genuine academic research time accurately.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (!hasUsagePermission) {
                OutlinedButton(
                    onClick = onExplainPermission,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Enable Usage Access for Real App Tracking")
                }
            }
        }
    }

    // Distraction Blocker Status Card
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Text(
                        text = "Distraction Blocker Status",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (state.distractionCount == 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = "${state.distractionCount} Distractions",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (state.distractionCount == 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            Text(
                text = "During Focus Mode, social and entertainment apps are monitored to protect your academic concentration.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun FocusSetupCard(
    subjects: List<String>,
    selectedSubject: String,
    onSelectSubject: (String) -> Unit,
    taskName: String,
    onTaskNameChange: (String) -> Unit,
    selectedDuration: Int,
    onSelectDuration: (Int) -> Unit,
    onStart: () -> Unit,
    onPreClassFocus: () -> Unit,
    onExplainPermission: () -> Unit,
    hasUsagePermission: Boolean
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Choose Study Subject",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            // Subject quick chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                subjects.take(3).forEach { subj ->
                    FilterChip(
                        selected = selectedSubject == subj,
                        onClick = { onSelectSubject(subj) },
                        label = { Text(subj, maxLines = 1) }
                    )
                }
            }

            OutlinedTextField(
                value = selectedSubject,
                onValueChange = onSelectSubject,
                label = { Text("Subject / Topic") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = taskName,
                onValueChange = onTaskNameChange,
                label = { Text("Task (e.g. Chapter 4 Practice Problems)") },
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Planned Duration",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(25, 45, 60, 90).forEach { mins ->
                    FilterChip(
                        selected = selectedDuration == mins,
                        onClick = { onSelectDuration(mins) },
                        label = { Text("${mins}m") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Button(
                onClick = onStart,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start ${selectedDuration}m Focus Session")
            }

            OutlinedButton(
                onClick = onPreClassFocus,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Timer, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Quick 5m Pre-Class Focus Mode")
            }

            if (!hasUsagePermission) {
                TextButton(
                    onClick = onExplainPermission,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("About Usage Stats & Distraction Blocking Permissions", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
