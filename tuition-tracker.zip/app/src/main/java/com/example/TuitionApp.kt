package com.example

import android.app.Application
import android.content.Context
import com.example.data.local.TuitionDatabase
import com.example.data.repository.TuitionRepository
import com.example.service.NotificationHelper

class TuitionApp : Application() {

    lateinit var database: TuitionDatabase
        private set

    lateinit var repository: TuitionRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = TuitionDatabase.getDatabase(this)
        repository = TuitionRepository(database, this)
        NotificationHelper.createNotificationChannels(this)
    }

    companion object {
        lateinit var instance: TuitionApp
            private set

        fun getAppContext(): Context = instance.applicationContext
    }
}
