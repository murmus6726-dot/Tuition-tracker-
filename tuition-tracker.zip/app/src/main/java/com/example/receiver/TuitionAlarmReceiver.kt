package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.TuitionDatabase
import com.example.service.NotificationHelper
import com.example.service.TtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TuitionAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TUITION_REMINDER = "com.aistudio.tuitiontracker.ACTION_TUITION_REMINDER"
        const val ACTION_FOCUS_MODE_START = "com.aistudio.tuitiontracker.ACTION_FOCUS_MODE_START"
        const val ACTION_HOMEWORK_REMINDER = "com.aistudio.tuitiontracker.ACTION_HOMEWORK_REMINDER"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = TuitionDatabase.getDatabase(context)
                val settings = db.tuitionDao().getUserSettingsSync()
                val voiceEnabled = settings?.voiceAnnouncementEnabled ?: true

                when (action) {
                    ACTION_TUITION_REMINDER -> {
                        val classId = intent.getLongExtra("class_id", -1L)
                        val subjectName = intent.getStringExtra("subject_name") ?: "Tuition"
                        val startTimeStr = intent.getStringExtra("start_time_str") ?: "soon"
                        val minutesBefore = intent.getIntExtra("minutes_before", 15)

                        NotificationHelper.showTuitionReminder(
                            context = context,
                            classId = classId,
                            subjectName = subjectName,
                            startTimeStr = startTimeStr,
                            minutesBefore = minutesBefore
                        )

                        if (voiceEnabled) {
                            val announcement = "Your $subjectName class is coming. Please get ready for the class."
                            val tts = TtsManager(context)
                            tts.speak(announcement)
                        }
                    }

                    ACTION_FOCUS_MODE_START -> {
                        val sessionTitle = intent.getStringExtra("session_title") ?: "Pre-Class Focus"
                        NotificationHelper.showFocusModeStarting(context, sessionTitle)
                    }

                    ACTION_HOMEWORK_REMINDER -> {
                        val homeworkId = intent.getLongExtra("homework_id", -1L)
                        val title = intent.getStringExtra("homework_title") ?: "Homework"
                        val subject = intent.getStringExtra("subject_name") ?: "Study"
                        NotificationHelper.showHomeworkReminder(context, homeworkId, title, subject)
                    }

                    Intent.ACTION_BOOT_COMPLETED -> {
                        // Reschedule upcoming active alarms
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
